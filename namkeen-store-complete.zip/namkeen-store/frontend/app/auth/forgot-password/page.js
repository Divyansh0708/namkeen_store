'use client';
import { useState } from 'react';
import Link from 'next/link';
import { useSearchParams, useRouter } from 'next/navigation';
import { FiMail, FiLock, FiArrowLeft } from 'react-icons/fi';
import { authAPI } from '../../../lib/api';
import toast from 'react-hot-toast';

export function ForgotPasswordPage() {
  const [email, setEmail] = useState('');
  const [sent, setSent] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      await authAPI.forgotPassword(email);
      setSent(true);
      toast.success('Reset email sent!');
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to send reset email');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-50 to-orange-50 flex items-center justify-center py-12 px-4">
      <div className="w-full max-w-md">
        <div className="card p-8">
          <Link href="/auth/login" className="flex items-center gap-2 text-gray-500 hover:text-primary-500 mb-6 text-sm font-semibold transition-colors">
            <FiArrowLeft size={16} /> Back to Login
          </Link>
          <h2 className="font-display text-2xl font-bold text-dark mb-2">Forgot Password?</h2>
          <p className="text-gray-500 mb-6">Enter your email address and we'll send you a reset link.</p>

          {sent ? (
            <div className="text-center py-6">
              <div className="text-5xl mb-4">📧</div>
              <h3 className="font-bold text-lg text-gray-800 mb-2">Check Your Email</h3>
              <p className="text-gray-500 text-sm">We've sent password reset instructions to <strong>{email}</strong>. The link expires in 30 minutes.</p>
              <Link href="/auth/login" className="btn-primary inline-block mt-6">Back to Login</Link>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="text-sm font-semibold text-gray-700 mb-1.5 block">Email Address</label>
                <div className="relative">
                  <FiMail className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={16} />
                  <input type="email" value={email} onChange={(e) => setEmail(e.target.value)}
                    placeholder="you@email.com" className="input-field pl-11" required />
                </div>
              </div>
              <button type="submit" disabled={loading} className="btn-primary w-full py-3.5 disabled:opacity-70">
                {loading ? 'Sending...' : 'Send Reset Link'}
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}

export default ForgotPasswordPage;

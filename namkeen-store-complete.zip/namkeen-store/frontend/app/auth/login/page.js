'use client';
import { useState } from 'react';
import Link from 'next/link';
import { useRouter, useSearchParams } from 'next/navigation';
import { FiMail, FiLock, FiUser, FiPhone, FiEye, FiEyeOff } from 'react-icons/fi';
import { useAuth } from '../../../context/AuthContext';
import toast from 'react-hot-toast';

export default function LoginPage() {
  const [isLogin, setIsLogin] = useState(true);
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [form, setForm] = useState({ name: '', email: '', password: '', phone: '' });
  const { login, register } = useAuth();
  const router = useRouter();
  const searchParams = useSearchParams();
  const redirect = searchParams.get('redirect') || '/';

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      if (isLogin) {
        await login(form.email, form.password);
        toast.success(`Welcome back! 👋`);
      } else {
        if (form.password.length < 6) { toast.error('Password must be at least 6 characters'); setLoading(false); return; }
        await register({ name: form.name, email: form.email, password: form.password, phone: form.phone });
        toast.success(`Welcome to Namkeen Store! 🎉`);
      }
      router.push(redirect);
    } catch (err) {
      toast.error(err.response?.data?.message || 'Authentication failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-50 to-orange-50 flex items-center justify-center py-12 px-4">
      <div className="w-full max-w-md">
        {/* Logo */}
        <div className="text-center mb-8">
          <Link href="/" className="inline-flex items-center gap-2 group">
            <div className="w-12 h-12 bg-gradient-to-br from-primary-500 to-primary-700 rounded-2xl flex items-center justify-center text-3xl shadow-orange">🍿</div>
            <div className="text-left">
              <div className="font-display font-bold text-2xl text-dark">Namkeen Store</div>
              <div className="text-xs text-primary-500 font-semibold tracking-widest uppercase">Premium Snacks</div>
            </div>
          </Link>
        </div>

        <div className="card p-8">
          {/* Tab toggle */}
          <div className="flex bg-gray-100 rounded-2xl p-1 mb-7">
            <button onClick={() => setIsLogin(true)}
              className={`flex-1 py-2.5 rounded-xl font-bold text-sm transition-all ${isLogin ? 'bg-white text-primary-600 shadow-sm' : 'text-gray-500 hover:text-gray-700'}`}>
              Sign In
            </button>
            <button onClick={() => setIsLogin(false)}
              className={`flex-1 py-2.5 rounded-xl font-bold text-sm transition-all ${!isLogin ? 'bg-white text-primary-600 shadow-sm' : 'text-gray-500 hover:text-gray-700'}`}>
              Create Account
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            {!isLogin && (
              <div>
                <label className="text-sm font-semibold text-gray-700 mb-1.5 block">Full Name *</label>
                <div className="relative">
                  <FiUser className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={16} />
                  <input type="text" value={form.name} onChange={(e) => setForm(p => ({...p, name: e.target.value}))}
                    placeholder="Rajesh Kumar" className="input-field pl-11" required />
                </div>
              </div>
            )}
            <div>
              <label className="text-sm font-semibold text-gray-700 mb-1.5 block">Email Address *</label>
              <div className="relative">
                <FiMail className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={16} />
                <input type="email" value={form.email} onChange={(e) => setForm(p => ({...p, email: e.target.value}))}
                  placeholder="you@email.com" className="input-field pl-11" required />
              </div>
            </div>
            {!isLogin && (
              <div>
                <label className="text-sm font-semibold text-gray-700 mb-1.5 block">Phone Number</label>
                <div className="relative">
                  <FiPhone className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={16} />
                  <input type="tel" value={form.phone} onChange={(e) => setForm(p => ({...p, phone: e.target.value}))}
                    placeholder="9876543210" className="input-field pl-11" />
                </div>
              </div>
            )}
            <div>
              <div className="flex justify-between mb-1.5">
                <label className="text-sm font-semibold text-gray-700">Password *</label>
                {isLogin && (
                  <Link href="/auth/forgot-password" className="text-sm text-primary-500 font-semibold hover:underline">Forgot?</Link>
                )}
              </div>
              <div className="relative">
                <FiLock className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={16} />
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={form.password}
                  onChange={(e) => setForm(p => ({...p, password: e.target.value}))}
                  placeholder={isLogin ? 'Your password' : 'Min 6 characters'}
                  className="input-field pl-11 pr-11"
                  required
                />
                <button type="button" onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600">
                  {showPassword ? <FiEyeOff size={16} /> : <FiEye size={16} />}
                </button>
              </div>
            </div>

            <button type="submit" disabled={loading}
              className="btn-primary w-full py-3.5 text-base font-bold mt-2 disabled:opacity-70 flex items-center justify-center gap-3">
              {loading
                ? <><span className="w-5 h-5 border-2 border-white/50 border-t-white rounded-full animate-spin" /> {isLogin ? 'Signing in...' : 'Creating account...'}</>
                : isLogin ? '🔓 Sign In' : '🎉 Create Account'
              }
            </button>
          </form>

          {/* Divider with test credentials */}
          {isLogin && (
            <div className="mt-5 p-3 bg-amber-50 rounded-xl text-xs text-amber-700 border border-amber-200">
              <strong>Demo credentials:</strong><br />
              User: user@test.com / Test@123456<br />
              Admin: admin@namkeenstore.com / Admin@123456
            </div>
          )}

          <p className="text-center text-sm text-gray-500 mt-5">
            {isLogin ? "Don't have an account? " : "Already have an account? "}
            <button onClick={() => setIsLogin(!isLogin)} className="text-primary-500 font-bold hover:underline">
              {isLogin ? 'Sign up free' : 'Sign in'}
            </button>
          </p>
        </div>
      </div>
    </div>
  );
}

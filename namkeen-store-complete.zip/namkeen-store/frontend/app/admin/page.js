'use client';
import { useEffect, useState } from 'react';
import { FiShoppingBag, FiUsers, FiPackage, FiTrendingUp, FiArrowUp, FiArrowDown } from 'react-icons/fi';
import { orderAPI } from '../../lib/api';

export default function AdminDashboard() {
  const [stats, setStats] = useState(null);
  const [salesData, setSalesData] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([
      orderAPI.getDashboardStats(),
      orderAPI.getSalesReport(),
    ]).then(([statsRes, salesRes]) => {
      setStats(statsRes.data.stats);
      setSalesData(salesRes.data.monthlyData);
    }).finally(() => setLoading(false));
  }, []);

  const STATUS_COLORS = {
    placed: 'bg-blue-100 text-blue-700',
    confirmed: 'bg-indigo-100 text-indigo-700',
    processing: 'bg-yellow-100 text-yellow-700',
    shipped: 'bg-orange-100 text-orange-700',
    delivered: 'bg-green-100 text-green-700',
    cancelled: 'bg-red-100 text-red-700',
  };

  const MONTH_NAMES = ['', 'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

  if (loading) return (
    <div>
      <div className="h-8 w-48 skeleton rounded mb-6" />
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        {Array(4).fill(null).map((_, i) => <div key={i} className="h-32 skeleton rounded-2xl" />)}
      </div>
    </div>
  );

  const statCards = [
    { label: 'Total Revenue', value: `₹${(stats?.totalRevenue || 0).toLocaleString('en-IN')}`, icon: FiTrendingUp, sub: `₹${(stats?.monthlyRevenue || 0).toLocaleString('en-IN')} this month`, color: 'from-primary-500 to-primary-600' },
    { label: 'Total Orders', value: stats?.totalOrders || 0, icon: FiShoppingBag, sub: `${stats?.todayOrders || 0} today`, color: 'from-blue-500 to-blue-600' },
    { label: 'Monthly Orders', value: stats?.monthlyOrders || 0, icon: FiPackage, sub: 'This month', color: 'from-green-500 to-green-600' },
    { label: 'Top Customers', value: (stats?.statusCounts?.find(s => s._id === 'delivered')?.count || 0) + ' delivered', icon: FiUsers, sub: 'Orders fulfilled', color: 'from-purple-500 to-purple-600' },
  ];

  return (
    <div>
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="font-display text-2xl font-bold text-dark">Dashboard</h1>
          <p className="text-gray-500 text-sm mt-1">Welcome back! Here's what's happening today.</p>
        </div>
        <div className="text-sm text-gray-500 bg-white px-4 py-2 rounded-xl border border-gray-200 font-semibold">
          {new Date().toLocaleDateString('en-IN', { weekday: 'long', day: 'numeric', month: 'long' })}
        </div>
      </div>

      {/* Stat cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        {statCards.map(({ label, value, icon: Icon, sub, color }) => (
          <div key={label} className="card p-5 overflow-hidden relative">
            <div className={`absolute -top-4 -right-4 w-20 h-20 bg-gradient-to-br ${color} opacity-10 rounded-full`} />
            <div className={`w-11 h-11 rounded-2xl bg-gradient-to-br ${color} flex items-center justify-center mb-3 shadow-sm`}>
              <Icon size={20} className="text-white" />
            </div>
            <div className="font-extrabold text-2xl text-gray-900">{value}</div>
            <div className="text-sm font-semibold text-gray-700 mt-0.5">{label}</div>
            <div className="text-xs text-gray-400 mt-1">{sub}</div>
          </div>
        ))}
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Monthly revenue chart */}
        <div className="lg:col-span-2 card p-6">
          <h2 className="font-bold text-gray-800 mb-5">Monthly Revenue</h2>
          {salesData.length > 0 ? (
            <div className="flex items-end gap-2 h-40">
              {salesData.map((d) => {
                const maxRevenue = Math.max(...salesData.map(x => x.revenue));
                const height = maxRevenue > 0 ? (d.revenue / maxRevenue) * 100 : 0;
                return (
                  <div key={`${d._id.year}-${d._id.month}`} className="flex-1 flex flex-col items-center gap-1 group">
                    <div className="text-xs font-semibold text-gray-500 opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap">
                      ₹{d.revenue.toLocaleString('en-IN')}
                    </div>
                    <div className="w-full relative flex items-end" style={{ height: '100px' }}>
                      <div
                        className="w-full bg-gradient-to-t from-primary-500 to-primary-300 rounded-t-lg hover:from-primary-600 hover:to-primary-400 transition-colors cursor-pointer"
                        style={{ height: `${Math.max(height, 4)}%` }}
                        title={`₹${d.revenue.toLocaleString('en-IN')}`}
                      />
                    </div>
                    <div className="text-xs text-gray-400 font-medium">{MONTH_NAMES[d._id.month]}</div>
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="h-40 flex items-center justify-center text-gray-400">No sales data yet</div>
          )}
        </div>

        {/* Order status breakdown */}
        <div className="card p-6">
          <h2 className="font-bold text-gray-800 mb-5">Order Status</h2>
          <div className="space-y-3">
            {(stats?.statusCounts || []).map(({ _id, count }) => {
              const totalOrders = stats?.totalOrders || 1;
              const pct = Math.round((count / totalOrders) * 100);
              return (
                <div key={_id}>
                  <div className="flex justify-between text-sm mb-1">
                    <span className={`badge capitalize ${STATUS_COLORS[_id] || 'bg-gray-100 text-gray-600'}`}>{_id}</span>
                    <span className="font-bold text-gray-800">{count}</span>
                  </div>
                  <div className="h-1.5 bg-gray-100 rounded-full overflow-hidden">
                    <div className="h-full bg-primary-500 rounded-full" style={{ width: `${pct}%` }} />
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Recent orders + top products */}
      <div className="grid lg:grid-cols-2 gap-6 mt-6">
        {/* Recent orders */}
        <div className="card p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-bold text-gray-800">Recent Orders</h2>
            <a href="/admin/orders" className="text-primary-500 text-sm font-semibold hover:underline">View All</a>
          </div>
          <div className="space-y-3">
            {(stats?.recentOrders || []).map((order) => (
              <div key={order._id} className="flex items-center gap-3 py-2 border-b border-gray-50 last:border-0">
                <div className="w-9 h-9 rounded-xl bg-primary-100 flex items-center justify-center text-primary-600 font-bold text-xs flex-shrink-0">
                  #{order.orderNumber?.slice(-4)}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="font-semibold text-sm text-gray-800 truncate">{order.user?.name}</div>
                  <div className="text-xs text-gray-400">{new Date(order.createdAt).toLocaleDateString('en-IN')}</div>
                </div>
                <div className="text-right flex-shrink-0">
                  <div className="font-bold text-sm text-gray-900">₹{order.totalPrice?.toFixed(0)}</div>
                  <span className={`text-xs badge capitalize ${STATUS_COLORS[order.orderStatus] || 'bg-gray-100 text-gray-600'}`}>
                    {order.orderStatus}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Top products */}
        <div className="card p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-bold text-gray-800">Top Products</h2>
            <a href="/admin/products" className="text-primary-500 text-sm font-semibold hover:underline">View All</a>
          </div>
          <div className="space-y-3">
            {(stats?.topProducts || []).map((p, i) => (
              <div key={p._id} className="flex items-center gap-3 py-2 border-b border-gray-50 last:border-0">
                <div className="w-8 h-8 rounded-xl bg-gray-100 flex items-center justify-center text-gray-500 font-bold text-sm flex-shrink-0">
                  #{i + 1}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="font-semibold text-sm text-gray-800 truncate">{p.name}</div>
                  <div className="text-xs text-gray-400">{p.totalSold} units sold</div>
                </div>
                <div className="font-bold text-sm text-primary-600 flex-shrink-0">₹{p.revenue?.toFixed(0)}</div>
              </div>
            ))}
            {!stats?.topProducts?.length && (
              <div className="text-center py-6 text-gray-400 text-sm">No sales data yet</div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

'use client';
import { useState, useEffect } from 'react';
import { FiSearch, FiX, FiChevronDown, FiEye } from 'react-icons/fi';
import { orderAPI } from '../../../lib/api';
import toast from 'react-hot-toast';

const STATUS_OPTIONS = ['placed','confirmed','processing','shipped','delivered','cancelled','returned'];
const STATUS_COLORS = {
  placed:     'bg-blue-100 text-blue-700',
  confirmed:  'bg-indigo-100 text-indigo-700',
  processing: 'bg-yellow-100 text-yellow-700',
  shipped:    'bg-orange-100 text-orange-700',
  delivered:  'bg-green-100 text-green-700',
  cancelled:  'bg-red-100 text-red-700',
  returned:   'bg-gray-100 text-gray-600',
};

export default function AdminOrdersPage() {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [pagination, setPagination] = useState({});
  const [page, setPage] = useState(1);
  const [selectedOrder, setSelectedOrder] = useState(null);
  const [updating, setUpdating] = useState(null);
  const [statusNote, setStatusNote] = useState('');
  const [trackingNum, setTrackingNum] = useState('');
  const [newStatus, setNewStatus] = useState('');

  const fetchOrders = async (p = 1) => {
    setLoading(true);
    try {
      const params = { page: p, limit: 20 };
      if (statusFilter) params.status = statusFilter;
      if (search) params.search = search;
      const { data } = await orderAPI.getAllAdmin(params);
      setOrders(data.orders);
      setPagination({ total: data.total, pages: data.pages });
    } catch { toast.error('Failed to load orders'); }
    finally { setLoading(false); }
  };

  useEffect(() => { fetchOrders(page); }, [page, statusFilter]);

  const handleUpdateStatus = async (orderId) => {
    if (!newStatus) return;
    setUpdating(orderId);
    try {
      const { data } = await orderAPI.updateStatus(orderId, {
        status: newStatus,
        note: statusNote,
        trackingNumber: trackingNum,
      });
      setOrders(prev => prev.map(o => o._id === orderId ? data.order : o));
      if (selectedOrder?._id === orderId) setSelectedOrder(data.order);
      toast.success(`Order status updated to ${newStatus}`);
      setStatusNote('');
      setTrackingNum('');
      setNewStatus('');
    } catch (err) {
      toast.error(err.response?.data?.message || 'Update failed');
    } finally { setUpdating(null); }
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="font-display text-2xl font-bold text-dark">Orders</h1>
          <p className="text-gray-500 text-sm mt-1">{pagination.total || 0} total orders</p>
        </div>
      </div>

      {/* Filters */}
      <div className="card p-4 mb-5 flex flex-wrap gap-3">
        <div className="relative flex-1 min-w-48">
          <FiSearch className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={16} />
          <input value={search} onChange={e => setSearch(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && fetchOrders(1)}
            placeholder="Search order number..." className="input-field pl-9 py-2.5 text-sm" />
        </div>
        <div className="relative">
          <select value={statusFilter} onChange={e => { setStatusFilter(e.target.value); setPage(1); }}
            className="input-field py-2.5 pr-9 text-sm appearance-none cursor-pointer">
            <option value="">All Status</option>
            {STATUS_OPTIONS.map(s => <option key={s} value={s} className="capitalize">{s.charAt(0).toUpperCase() + s.slice(1)}</option>)}
          </select>
          <FiChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none" size={14} />
        </div>
        {(search || statusFilter) && (
          <button onClick={() => { setSearch(''); setStatusFilter(''); setPage(1); }} className="btn-secondary py-2.5 px-4 text-sm flex items-center gap-2">
            <FiX size={14} /> Clear
          </button>
        )}
      </div>

      {/* Status tabs */}
      <div className="flex gap-2 overflow-x-auto pb-2 mb-5">
        {['', ...STATUS_OPTIONS].map(s => (
          <button key={s} onClick={() => { setStatusFilter(s); setPage(1); }}
            className={`px-4 py-2 rounded-xl text-sm font-semibold whitespace-nowrap transition-colors ${statusFilter === s ? 'bg-primary-500 text-white' : 'bg-white text-gray-600 hover:bg-gray-50 border border-gray-200'}`}>
            {s ? s.charAt(0).toUpperCase() + s.slice(1) : 'All'}
          </button>
        ))}
      </div>

      <div className="grid xl:grid-cols-3 gap-6">
        {/* Orders table */}
        <div className="xl:col-span-2">
          <div className="card overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-gray-50 border-b border-gray-100">
                  <tr>
                    {['Order', 'Customer', 'Items', 'Total', 'Payment', 'Status', ''].map(h => (
                      <th key={h} className="px-4 py-3 text-left font-bold text-gray-500 text-xs uppercase tracking-wider whitespace-nowrap">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-50">
                  {loading ? Array(8).fill(null).map((_, i) => (
                    <tr key={i}>{Array(7).fill(null).map((_, j) => <td key={j} className="px-4 py-3"><div className="h-4 skeleton rounded" /></td>)}</tr>
                  )) : orders.map(order => (
                    <tr key={order._id} className={`hover:bg-gray-50 transition-colors cursor-pointer ${selectedOrder?._id === order._id ? 'bg-primary-50' : ''}`}
                      onClick={() => setSelectedOrder(order)}>
                      <td className="px-4 py-3">
                        <div className="font-bold text-gray-800 text-xs">#{order.orderNumber}</div>
                        <div className="text-gray-400 text-xs">{new Date(order.createdAt).toLocaleDateString('en-IN')}</div>
                      </td>
                      <td className="px-4 py-3">
                        <div className="font-medium text-gray-700 text-xs">{order.user?.name}</div>
                        <div className="text-gray-400 text-xs truncate max-w-28">{order.user?.email}</div>
                      </td>
                      <td className="px-4 py-3 text-gray-600 text-xs">{order.items.length} item{order.items.length > 1 ? 's' : ''}</td>
                      <td className="px-4 py-3 font-bold text-gray-900 text-xs">₹{order.totalPrice.toFixed(0)}</td>
                      <td className="px-4 py-3">
                        <span className={`badge text-xs ${order.paymentStatus === 'paid' ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'}`}>
                          {order.paymentStatus}
                        </span>
                      </td>
                      <td className="px-4 py-3">
                        <span className={`badge text-xs capitalize ${STATUS_COLORS[order.orderStatus]}`}>{order.orderStatus}</span>
                      </td>
                      <td className="px-4 py-3">
                        <FiEye size={14} className="text-gray-400" />
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
              {!loading && orders.length === 0 && (
                <div className="text-center py-12 text-gray-400">
                  <div className="text-4xl mb-2">📦</div>
                  <p>No orders found</p>
                </div>
              )}
            </div>
            {pagination.pages > 1 && (
              <div className="flex items-center justify-between px-4 py-3 border-t border-gray-100 text-sm">
                <span className="text-gray-500">Page {page} of {pagination.pages}</span>
                <div className="flex gap-2">
                  <button onClick={() => setPage(p => Math.max(1, p-1))} disabled={page === 1} className="px-3 py-1.5 rounded-lg border border-gray-200 hover:bg-gray-50 disabled:opacity-40 font-semibold text-sm">Prev</button>
                  <button onClick={() => setPage(p => Math.min(pagination.pages, p+1))} disabled={page === pagination.pages} className="px-3 py-1.5 rounded-lg border border-gray-200 hover:bg-gray-50 disabled:opacity-40 font-semibold text-sm">Next</button>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Order detail panel */}
        <div>
          {selectedOrder ? (
            <div className="card p-5 sticky top-24 space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="font-bold text-gray-800">#{selectedOrder.orderNumber}</h3>
                <button onClick={() => setSelectedOrder(null)} className="text-gray-400 hover:text-gray-600"><FiX size={18} /></button>
              </div>
              <div className="text-xs text-gray-500 space-y-1">
                <div><span className="font-semibold text-gray-700">Customer:</span> {selectedOrder.user?.name}</div>
                <div><span className="font-semibold text-gray-700">Email:</span> {selectedOrder.user?.email}</div>
                <div><span className="font-semibold text-gray-700">Phone:</span> {selectedOrder.user?.phone || selectedOrder.shippingAddress?.phone}</div>
              </div>
              <div className="bg-gray-50 rounded-xl p-3 text-xs space-y-1">
                <div className="font-semibold text-gray-700 mb-1">Delivery Address</div>
                <div>{selectedOrder.shippingAddress?.name}</div>
                <div>{selectedOrder.shippingAddress?.street}</div>
                <div>{selectedOrder.shippingAddress?.city}, {selectedOrder.shippingAddress?.state} — {selectedOrder.shippingAddress?.pincode}</div>
              </div>
              <div>
                <div className="font-semibold text-gray-700 text-xs mb-2">Items</div>
                <div className="space-y-2">
                  {selectedOrder.items.map((item, i) => (
                    <div key={i} className="flex gap-2 text-xs">
                      <div className="flex-1 text-gray-700 font-medium line-clamp-1">{item.name}</div>
                      <div className="text-gray-500">×{item.quantity}</div>
                      <div className="font-bold text-gray-900">₹{(item.price * item.quantity).toFixed(0)}</div>
                    </div>
                  ))}
                </div>
              </div>
              <div className="bg-primary-50 rounded-xl p-3 text-xs space-y-1">
                <div className="flex justify-between"><span>Subtotal</span><span>₹{selectedOrder.itemsPrice?.toFixed(0)}</span></div>
                <div className="flex justify-between"><span>Shipping</span><span>{selectedOrder.shippingPrice === 0 ? 'FREE' : `₹${selectedOrder.shippingPrice}`}</span></div>
                <div className="flex justify-between font-bold text-sm pt-1 border-t border-primary-200"><span>Total</span><span className="text-primary-600">₹{selectedOrder.totalPrice?.toFixed(0)}</span></div>
              </div>

              {/* Update status */}
              <div>
                <div className="font-semibold text-gray-700 text-xs mb-2">Update Status</div>
                <div className="space-y-2">
                  <select value={newStatus} onChange={e => setNewStatus(e.target.value)} className="input-field py-2 text-sm">
                    <option value="">Select new status...</option>
                    {STATUS_OPTIONS.map(s => <option key={s} value={s} className="capitalize">{s.charAt(0).toUpperCase() + s.slice(1)}</option>)}
                  </select>
                  <input value={trackingNum} onChange={e => setTrackingNum(e.target.value)}
                    placeholder="Tracking number (optional)" className="input-field py-2 text-sm" />
                  <input value={statusNote} onChange={e => setStatusNote(e.target.value)}
                    placeholder="Note (optional)" className="input-field py-2 text-sm" />
                  <button onClick={() => handleUpdateStatus(selectedOrder._id)}
                    disabled={!newStatus || updating === selectedOrder._id}
                    className="btn-primary w-full py-2.5 text-sm disabled:opacity-60">
                    {updating === selectedOrder._id ? 'Updating...' : 'Update Status'}
                  </button>
                </div>
              </div>

              {/* Status history */}
              {selectedOrder.statusHistory?.length > 0 && (
                <div>
                  <div className="font-semibold text-gray-700 text-xs mb-2">Status History</div>
                  <div className="space-y-1.5">
                    {[...selectedOrder.statusHistory].reverse().map((h, i) => (
                      <div key={i} className="flex items-start gap-2 text-xs">
                        <span className={`badge capitalize flex-shrink-0 ${STATUS_COLORS[h.status]}`}>{h.status}</span>
                        <span className="text-gray-400">{new Date(h.timestamp).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          ) : (
            <div className="card p-8 text-center text-gray-400">
              <FiEye size={32} className="mx-auto mb-2 opacity-50" />
              <p className="text-sm">Click an order to view details</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

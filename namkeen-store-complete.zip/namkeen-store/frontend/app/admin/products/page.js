'use client';
import { useState, useEffect, useRef } from 'react';
import { FiPlus, FiEdit2, FiTrash2, FiSearch, FiX, FiUpload, FiStar } from 'react-icons/fi';
import { productAPI, categoryAPI, adminAPI } from '../../../lib/api';
import toast from 'react-hot-toast';

const EMPTY_FORM = {
  name: '', shortDescription: '', description: '', ingredients: '',
  price: '', offerPrice: '', category: '', stock: '', weight: '',
  sku: '', shelfLife: '', storage: '', brand: 'Namkeen Store',
  isFeatured: false, isBestSeller: false, isNew: false, isActive: true,
  images: [],
  nutritionInfo: { calories: '', protein: '', carbs: '', fat: '', fiber: '', sodium: '' },
  tags: '',
};

export default function AdminProductsPage() {
  const [products, setProducts] = useState([]);
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editProduct, setEditProduct] = useState(null);
  const [form, setForm] = useState(EMPTY_FORM);
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [search, setSearch] = useState('');
  const [pagination, setPagination] = useState({});
  const [page, setPage] = useState(1);
  const fileRef = useRef(null);

  const fetchProducts = async (p = 1, kw = '') => {
    setLoading(true);
    try {
      const params = { page: p, limit: 15, sort: '-createdAt' };
      if (kw) params.keyword = kw;
      const { data } = await productAPI.getAll(params);
      setProducts(data.products);
      setPagination(data.pagination);
    } catch (err) {
      toast.error('Failed to load products');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProducts(page, search);
    categoryAPI.getAll().then(({ data }) => setCategories(data.categories)).catch(() => {});
  }, [page]);

  const openAdd = () => { setEditProduct(null); setForm(EMPTY_FORM); setShowModal(true); };
  const openEdit = (p) => {
    setEditProduct(p);
    setForm({
      ...EMPTY_FORM, ...p,
      category: p.category?._id || '',
      tags: Array.isArray(p.tags) ? p.tags.join(', ') : '',
      nutritionInfo: p.nutritionInfo || EMPTY_FORM.nutritionInfo,
      offerPrice: p.offerPrice || '',
    });
    setShowModal(true);
  };

  const handleImageUpload = async (e) => {
    const files = e.target.files;
    if (!files?.length) return;
    setUploading(true);
    try {
      const formData = new FormData();
      Array.from(files).forEach(f => formData.append('images', f));
      const { data } = await adminAPI.uploadImages(formData);
      const urls = data.images.map(img => img.url);
      setForm(prev => ({ ...prev, images: [...(prev.images || []), ...urls] }));
      toast.success(`${files.length} image(s) uploaded`);
    } catch {
      toast.error('Image upload failed');
    } finally {
      setUploading(false);
    }
  };

  const removeImage = (idx) => {
    setForm(prev => ({ ...prev, images: prev.images.filter((_, i) => i !== idx) }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      const payload = {
        ...form,
        price: Number(form.price),
        offerPrice: form.offerPrice ? Number(form.offerPrice) : undefined,
        stock: Number(form.stock),
        tags: form.tags ? form.tags.split(',').map(t => t.trim()).filter(Boolean) : [],
      };
      if (editProduct) {
        const { data } = await productAPI.update(editProduct._id, payload);
        setProducts(prev => prev.map(p => p._id === editProduct._id ? data.product : p));
        toast.success('Product updated!');
      } else {
        const { data } = await productAPI.create(payload);
        setProducts(prev => [data.product, ...prev]);
        toast.success('Product created!');
      }
      setShowModal(false);
    } catch (err) {
      toast.error(err.response?.data?.message || 'Save failed');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id) => {
    if (!confirm('Delete this product permanently?')) return;
    try {
      await productAPI.delete(id);
      setProducts(prev => prev.filter(p => p._id !== id));
      toast.success('Product deleted');
    } catch (err) {
      toast.error(err.response?.data?.message || 'Delete failed');
    }
  };

  const setF = (key, val) => setForm(prev => ({ ...prev, [key]: val }));
  const setNutrition = (key, val) => setForm(prev => ({ ...prev, nutritionInfo: { ...prev.nutritionInfo, [key]: val } }));

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="font-display text-2xl font-bold text-dark">Products</h1>
          <p className="text-gray-500 text-sm mt-1">{pagination.total || 0} total products</p>
        </div>
        <button onClick={openAdd} className="btn-primary flex items-center gap-2">
          <FiPlus size={18} /> Add Product
        </button>
      </div>

      {/* Search */}
      <div className="card p-4 mb-5 flex gap-3">
        <div className="relative flex-1">
          <FiSearch className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={16} />
          <input value={search} onChange={e => setSearch(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && fetchProducts(1, search)}
            placeholder="Search products..." className="input-field pl-9 py-2.5 text-sm" />
        </div>
        <button onClick={() => fetchProducts(1, search)} className="btn-primary py-2.5 px-5 text-sm">Search</button>
        {search && <button onClick={() => { setSearch(''); fetchProducts(1, ''); }} className="btn-secondary py-2.5 px-4 text-sm"><FiX size={16} /></button>}
      </div>

      {/* Table */}
      <div className="card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-gray-50 border-b border-gray-100">
              <tr>
                {['Product', 'Category', 'Price', 'Stock', 'Status', 'Rating', 'Actions'].map(h => (
                  <th key={h} className="px-4 py-3 text-left font-bold text-gray-600 text-xs uppercase tracking-wider whitespace-nowrap">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50">
              {loading ? (
                Array(8).fill(null).map((_, i) => (
                  <tr key={i}>
                    {Array(7).fill(null).map((_, j) => (
                      <td key={j} className="px-4 py-3"><div className="h-4 skeleton rounded" /></td>
                    ))}
                  </tr>
                ))
              ) : products.map(p => (
                <tr key={p._id} className="hover:bg-gray-50 transition-colors">
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl overflow-hidden bg-gray-100 flex-shrink-0">
                        {p.images?.[0] && <img src={p.images[0]} alt="" className="w-full h-full object-cover" />}
                      </div>
                      <div>
                        <div className="font-semibold text-gray-800 line-clamp-1 max-w-40">{p.name}</div>
                        <div className="text-xs text-gray-400">{p.weight}</div>
                      </div>
                    </div>
                  </td>
                  <td className="px-4 py-3 text-gray-600">{p.category?.name || '—'}</td>
                  <td className="px-4 py-3">
                    <div className="font-bold text-gray-900">₹{p.offerPrice || p.price}</div>
                    {p.offerPrice && <div className="text-xs text-gray-400 line-through">₹{p.price}</div>}
                  </td>
                  <td className="px-4 py-3">
                    <span className={`badge text-xs font-bold ${p.stock > 10 ? 'bg-green-100 text-green-700' : p.stock > 0 ? 'bg-yellow-100 text-yellow-700' : 'bg-red-100 text-red-700'}`}>
                      {p.stock > 0 ? p.stock : 'Out'}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex flex-wrap gap-1">
                      {p.isFeatured && <span className="badge bg-purple-100 text-purple-700 text-xs">Featured</span>}
                      {p.isBestSeller && <span className="badge bg-amber-100 text-amber-700 text-xs">Best Seller</span>}
                      {p.isNew && <span className="badge bg-green-100 text-green-700 text-xs">New</span>}
                      {!p.isActive && <span className="badge bg-red-100 text-red-700 text-xs">Inactive</span>}
                    </div>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-1">
                      <FiStar size={12} className="text-amber-400 fill-amber-400" />
                      <span className="font-semibold text-gray-700">{p.ratings?.toFixed(1) || '0'}</span>
                      <span className="text-gray-400 text-xs">({p.numReviews})</span>
                    </div>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex gap-1">
                      <button onClick={() => openEdit(p)} className="p-2 rounded-lg hover:bg-blue-50 text-gray-400 hover:text-blue-500 transition-colors" title="Edit">
                        <FiEdit2 size={15} />
                      </button>
                      <button onClick={() => handleDelete(p._id)} className="p-2 rounded-lg hover:bg-red-50 text-gray-400 hover:text-red-500 transition-colors" title="Delete">
                        <FiTrash2 size={15} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {!loading && products.length === 0 && (
            <div className="text-center py-12 text-gray-400">
              <div className="text-4xl mb-2">📦</div>
              <p>No products found</p>
            </div>
          )}
        </div>

        {/* Pagination */}
        {pagination.pages > 1 && (
          <div className="flex items-center justify-between px-4 py-3 border-t border-gray-100 text-sm">
            <span className="text-gray-500">Page {page} of {pagination.pages}</span>
            <div className="flex gap-2">
              <button onClick={() => setPage(p => Math.max(1, p - 1))} disabled={page === 1}
                className="px-3 py-1.5 rounded-lg border border-gray-200 hover:bg-gray-50 disabled:opacity-40 font-semibold">Prev</button>
              <button onClick={() => setPage(p => Math.min(pagination.pages, p + 1))} disabled={page === pagination.pages}
                className="px-3 py-1.5 rounded-lg border border-gray-200 hover:bg-gray-50 disabled:opacity-40 font-semibold">Next</button>
            </div>
          </div>
        )}
      </div>

      {/* Modal */}
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-start justify-center bg-black/50 backdrop-blur-sm overflow-y-auto py-6 px-4">
          <div className="bg-white rounded-3xl shadow-2xl w-full max-w-3xl animate-slide-up">
            <div className="flex items-center justify-between p-6 border-b border-gray-100">
              <h2 className="font-bold text-xl text-gray-800">{editProduct ? 'Edit Product' : 'Add New Product'}</h2>
              <button onClick={() => setShowModal(false)} className="p-2 rounded-xl hover:bg-gray-100"><FiX size={20} /></button>
            </div>
            <form onSubmit={handleSubmit} className="p-6 space-y-5 max-h-[80vh] overflow-y-auto">
              {/* Images */}
              <div>
                <label className="text-sm font-bold text-gray-700 mb-2 block">Product Images</label>
                <div className="flex flex-wrap gap-2 mb-2">
                  {(form.images || []).map((img, i) => (
                    <div key={i} className="relative w-20 h-20 rounded-xl overflow-hidden border-2 border-gray-200 group">
                      <img src={img} alt="" className="w-full h-full object-cover" />
                      <button type="button" onClick={() => removeImage(i)}
                        className="absolute inset-0 bg-black/50 text-white hidden group-hover:flex items-center justify-center">
                        <FiX size={16} />
                      </button>
                    </div>
                  ))}
                  <button type="button" onClick={() => fileRef.current?.click()}
                    disabled={uploading}
                    className="w-20 h-20 rounded-xl border-2 border-dashed border-gray-300 hover:border-primary-400 flex flex-col items-center justify-center text-gray-400 hover:text-primary-500 transition-colors">
                    {uploading ? <span className="w-5 h-5 border-2 border-gray-300 border-t-primary-500 rounded-full animate-spin" /> : <><FiUpload size={18} /><span className="text-xs mt-1">Upload</span></>}
                  </button>
                </div>
                <input ref={fileRef} type="file" accept="image/*" multiple className="hidden" onChange={handleImageUpload} />
                <p className="text-xs text-gray-400">Or paste URL directly in the images field</p>
              </div>

              <div className="grid sm:grid-cols-2 gap-4">
                <div className="sm:col-span-2">
                  <label className="text-sm font-bold text-gray-700 mb-1.5 block">Product Name *</label>
                  <input value={form.name} onChange={e => setF('name', e.target.value)} placeholder="e.g. Bikaneri Bhujia Premium" className="input-field" required />
                </div>
                <div>
                  <label className="text-sm font-bold text-gray-700 mb-1.5 block">Category *</label>
                  <select value={form.category} onChange={e => setF('category', e.target.value)} className="input-field" required>
                    <option value="">Select Category</option>
                    {categories.map(c => <option key={c._id} value={c._id}>{c.icon} {c.name}</option>)}
                  </select>
                </div>
                <div>
                  <label className="text-sm font-bold text-gray-700 mb-1.5 block">Weight/Size</label>
                  <input value={form.weight} onChange={e => setF('weight', e.target.value)} placeholder="e.g. 400g" className="input-field" />
                </div>
                <div>
                  <label className="text-sm font-bold text-gray-700 mb-1.5 block">MRP (₹) *</label>
                  <input type="number" value={form.price} onChange={e => setF('price', e.target.value)} placeholder="120" className="input-field" required min="0" />
                </div>
                <div>
                  <label className="text-sm font-bold text-gray-700 mb-1.5 block">Offer Price (₹)</label>
                  <input type="number" value={form.offerPrice} onChange={e => setF('offerPrice', e.target.value)} placeholder="99" className="input-field" min="0" />
                </div>
                <div>
                  <label className="text-sm font-bold text-gray-700 mb-1.5 block">Stock *</label>
                  <input type="number" value={form.stock} onChange={e => setF('stock', e.target.value)} placeholder="100" className="input-field" required min="0" />
                </div>
                <div>
                  <label className="text-sm font-bold text-gray-700 mb-1.5 block">SKU</label>
                  <input value={form.sku} onChange={e => setF('sku', e.target.value)} placeholder="NS-BHU-001" className="input-field" />
                </div>
              </div>

              <div>
                <label className="text-sm font-bold text-gray-700 mb-1.5 block">Short Description</label>
                <input value={form.shortDescription} onChange={e => setF('shortDescription', e.target.value)} placeholder="One line product pitch" className="input-field" />
              </div>
              <div>
                <label className="text-sm font-bold text-gray-700 mb-1.5 block">Full Description *</label>
                <textarea value={form.description} onChange={e => setF('description', e.target.value)} rows={4} className="input-field resize-none" required placeholder="Detailed product description..." />
              </div>
              <div>
                <label className="text-sm font-bold text-gray-700 mb-1.5 block">Ingredients</label>
                <textarea value={form.ingredients} onChange={e => setF('ingredients', e.target.value)} rows={2} className="input-field resize-none" placeholder="List all ingredients..." />
              </div>

              <div className="grid sm:grid-cols-3 gap-4">
                <div>
                  <label className="text-sm font-bold text-gray-700 mb-1.5 block">Shelf Life</label>
                  <input value={form.shelfLife} onChange={e => setF('shelfLife', e.target.value)} placeholder="6 months" className="input-field" />
                </div>
                <div>
                  <label className="text-sm font-bold text-gray-700 mb-1.5 block">Storage</label>
                  <input value={form.storage} onChange={e => setF('storage', e.target.value)} placeholder="Cool, dry place" className="input-field" />
                </div>
                <div>
                  <label className="text-sm font-bold text-gray-700 mb-1.5 block">Brand</label>
                  <input value={form.brand} onChange={e => setF('brand', e.target.value)} className="input-field" />
                </div>
              </div>

              <div>
                <label className="text-sm font-bold text-gray-700 mb-1.5 block">Tags (comma-separated)</label>
                <input value={form.tags} onChange={e => setF('tags', e.target.value)} placeholder="bhujia, spicy, rajasthani" className="input-field" />
              </div>

              {/* Nutrition */}
              <div>
                <label className="text-sm font-bold text-gray-700 mb-2 block">Nutrition Info (per 100g)</label>
                <div className="grid grid-cols-3 gap-3">
                  {Object.keys(EMPTY_FORM.nutritionInfo).map(key => (
                    <div key={key}>
                      <label className="text-xs text-gray-500 mb-1 block capitalize">{key}</label>
                      <input value={form.nutritionInfo?.[key] || ''} onChange={e => setNutrition(key, e.target.value)}
                        placeholder={key === 'calories' ? '520 kcal' : '18g'} className="input-field py-2 text-sm" />
                    </div>
                  ))}
                </div>
              </div>

              {/* Flags */}
              <div>
                <label className="text-sm font-bold text-gray-700 mb-2 block">Product Labels</label>
                <div className="flex flex-wrap gap-4">
                  {[
                    { key: 'isFeatured', label: '🔥 Featured' },
                    { key: 'isBestSeller', label: '⭐ Best Seller' },
                    { key: 'isNew', label: '✨ New Arrival' },
                    { key: 'isActive', label: '✅ Active' },
                  ].map(({ key, label }) => (
                    <label key={key} className="flex items-center gap-2 cursor-pointer">
                      <input type="checkbox" checked={!!form[key]} onChange={e => setF(key, e.target.checked)} className="accent-primary-500 w-4 h-4" />
                      <span className="text-sm font-medium text-gray-700">{label}</span>
                    </label>
                  ))}
                </div>
              </div>

              <div className="flex gap-3 pt-2">
                <button type="submit" disabled={saving} className="btn-primary flex-1 py-3 disabled:opacity-70">
                  {saving ? 'Saving...' : editProduct ? 'Update Product' : 'Create Product'}
                </button>
                <button type="button" onClick={() => setShowModal(false)} className="btn-secondary px-6 py-3">Cancel</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

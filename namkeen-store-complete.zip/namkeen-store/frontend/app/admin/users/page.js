'use client';
import { useState, useEffect } from 'react';
import { FiSearch, FiUser, FiShield, FiX, FiPlus, FiEdit2, FiTrash2 } from 'react-icons/fi';
import { adminAPI } from '../../../lib/api';
import toast from 'react-hot-toast';

export default function AdminUsersPage() {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [total, setTotal] = useState(0);

  const fetchUsers = async (kw = '') => {
    setLoading(true);
    try {
      const { data } = await adminAPI.getUsers({ search: kw, limit: 50 });
      setUsers(data.users);
      setTotal(data.total);
    } catch { toast.error('Failed to load users'); }
    finally { setLoading(false); }
  };

  useEffect(() => { fetchUsers(); }, []);

  const handleRoleToggle = async (user) => {
    const newRole = user.role === 'admin' ? 'user' : 'admin';
    if (!confirm(`Change ${user.name}'s role to ${newRole}?`)) return;
    try {
      const { data } = await adminAPI.updateUser(user._id, { role: newRole });
      setUsers(prev => prev.map(u => u._id === user._id ? data.user : u));
      toast.success(`Role updated to ${newRole}`);
    } catch { toast.error('Failed to update role'); }
  };

  const handleToggleActive = async (user) => {
    try {
      const { data } = await adminAPI.updateUser(user._id, { isActive: !user.isActive });
      setUsers(prev => prev.map(u => u._id === user._id ? data.user : u));
      toast.success(`User ${data.user.isActive ? 'activated' : 'deactivated'}`);
    } catch { toast.error('Failed to update user'); }
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="font-display text-2xl font-bold text-dark">Users</h1>
          <p className="text-gray-500 text-sm mt-1">{total} registered users</p>
        </div>
      </div>

      <div className="card p-4 mb-5 flex gap-3">
        <div className="relative flex-1">
          <FiSearch className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={16} />
          <input value={search} onChange={e => setSearch(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && fetchUsers(search)}
            placeholder="Search by name or email..." className="input-field pl-9 py-2.5 text-sm" />
        </div>
        <button onClick={() => fetchUsers(search)} className="btn-primary py-2.5 px-5 text-sm">Search</button>
        {search && <button onClick={() => { setSearch(''); fetchUsers(''); }} className="btn-secondary py-2.5 px-4 text-sm"><FiX size={16} /></button>}
      </div>

      <div className="card overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-gray-50 border-b border-gray-100">
            <tr>
              {['User', 'Email', 'Phone', 'Role', 'Status', 'Joined', 'Actions'].map(h => (
                <th key={h} className="px-4 py-3 text-left font-bold text-gray-500 text-xs uppercase tracking-wider whitespace-nowrap">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-50">
            {loading ? Array(8).fill(null).map((_, i) => (
              <tr key={i}>{Array(7).fill(null).map((_, j) => <td key={j} className="px-4 py-3"><div className="h-4 skeleton rounded" /></td>)}</tr>
            )) : users.map(user => (
              <tr key={user._id} className="hover:bg-gray-50 transition-colors">
                <td className="px-4 py-3">
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-primary-400 to-primary-600 flex items-center justify-center text-white font-bold text-sm flex-shrink-0">
                      {user.name?.charAt(0).toUpperCase()}
                    </div>
                    <span className="font-semibold text-gray-800">{user.name}</span>
                  </div>
                </td>
                <td className="px-4 py-3 text-gray-600 text-xs">{user.email}</td>
                <td className="px-4 py-3 text-gray-500 text-xs">{user.phone || '—'}</td>
                <td className="px-4 py-3">
                  <span className={`badge text-xs ${user.role === 'admin' ? 'bg-purple-100 text-purple-700' : 'bg-gray-100 text-gray-600'}`}>
                    {user.role}
                  </span>
                </td>
                <td className="px-4 py-3">
                  <span className={`badge text-xs ${user.isActive ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-600'}`}>
                    {user.isActive ? 'Active' : 'Inactive'}
                  </span>
                </td>
                <td className="px-4 py-3 text-gray-400 text-xs">
                  {new Date(user.createdAt).toLocaleDateString('en-IN')}
                </td>
                <td className="px-4 py-3">
                  <div className="flex gap-1">
                    <button onClick={() => handleRoleToggle(user)} title={user.role === 'admin' ? 'Remove admin' : 'Make admin'}
                      className={`p-1.5 rounded-lg transition-colors ${user.role === 'admin' ? 'hover:bg-purple-50 text-purple-400 hover:text-purple-600' : 'hover:bg-gray-50 text-gray-400 hover:text-gray-600'}`}>
                      <FiShield size={14} />
                    </button>
                    <button onClick={() => handleToggleActive(user)} title={user.isActive ? 'Deactivate' : 'Activate'}
                      className={`p-1.5 rounded-lg transition-colors ${user.isActive ? 'hover:bg-red-50 text-gray-400 hover:text-red-500' : 'hover:bg-green-50 text-gray-400 hover:text-green-500'}`}>
                      <FiUser size={14} />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {!loading && users.length === 0 && (
          <div className="text-center py-12 text-gray-400">
            <div className="text-4xl mb-2">👥</div>
            <p>No users found</p>
          </div>
        )}
      </div>
    </div>
  );
}

'use client';
import { useState, useEffect } from 'react';
import { FiPlus, FiEdit2, FiTrash2, FiX } from 'react-icons/fi';
import { categoryAPI } from '../../../lib/api';
import toast from 'react-hot-toast';

const EMOJI_OPTIONS = ['🫘','🍜','🥜','🥔','🥗','💚','🌾','🏺','🍿','🌽','🫙','🥕','🌶️','🧄','🫚'];
const EMPTY_FORM = { name: '', description: '', icon: '🍿', sortOrder: 0, isActive: true };

export default function AdminCategoriesPage() {
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editCat, setEditCat] = useState(null);
  const [form, setForm] = useState(EMPTY_FORM);
  const [saving, setSaving] = useState(false);

  const fetchCategories = async () => {
    try {
      const { data } = await categoryAPI.getAllAdmin();
      setCategories(data.categories);
    } catch { toast.error('Failed to load categories'); }
    finally { setLoading(false); }
  };

  useEffect(() => { fetchCategories(); }, []);

  const openAdd = () => { setEditCat(null); setForm(EMPTY_FORM); setShowModal(true); };
  const openEdit = (c) => { setEditCat(c); setForm({ name: c.name, description: c.description || '', icon: c.icon || '🍿', sortOrder: c.sortOrder || 0, isActive: c.isActive }); setShowModal(true); };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      if (editCat) {
        const { data } = await categoryAPI.update(editCat._id, form);
        setCategories(prev => prev.map(c => c._id === editCat._id ? data.category : c));
        toast.success('Category updated!');
      } else {
        const { data } = await categoryAPI.create(form);
        setCategories(prev => [...prev, data.category]);
        toast.success('Category created!');
      }
      setShowModal(false);
    } catch (err) {
      toast.error(err.response?.data?.message || 'Save failed');
    } finally { setSaving(false); }
  };

  const handleDelete = async (id) => {
    if (!confirm('Delete this category? Make sure no products are assigned to it.')) return;
    try {
      await categoryAPI.delete(id);
      setCategories(prev => prev.filter(c => c._id !== id));
      toast.success('Category deleted');
    } catch (err) {
      toast.error(err.response?.data?.message || 'Delete failed');
    }
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="font-display text-2xl font-bold text-dark">Categories</h1>
          <p className="text-gray-500 text-sm mt-1">{categories.length} categories</p>
        </div>
        <button onClick={openAdd} className="btn-primary flex items-center gap-2">
          <FiPlus size={18} /> Add Category
        </button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
        {loading ? Array(8).fill(null).map((_, i) => <div key={i} className="h-36 skeleton rounded-2xl" />) :
          categories.map(cat => (
            <div key={cat._id} className={`card p-5 transition-all ${!cat.isActive ? 'opacity-60' : ''}`}>
              <div className="flex items-start justify-between">
                <div className="text-4xl mb-3">{cat.icon}</div>
                <div className="flex gap-1">
                  <button onClick={() => openEdit(cat)} className="p-2 rounded-lg hover:bg-blue-50 text-gray-400 hover:text-blue-500 transition-colors">
                    <FiEdit2 size={14} />
                  </button>
                  <button onClick={() => handleDelete(cat._id)} className="p-2 rounded-lg hover:bg-red-50 text-gray-400 hover:text-red-500 transition-colors">
                    <FiTrash2 size={14} />
                  </button>
                </div>
              </div>
              <h3 className="font-bold text-gray-800">{cat.name}</h3>
              {cat.description && <p className="text-sm text-gray-500 mt-1 line-clamp-2">{cat.description}</p>}
              <div className="flex items-center gap-2 mt-3">
                <span className={`badge text-xs ${cat.isActive ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-600'}`}>
                  {cat.isActive ? 'Active' : 'Inactive'}
                </span>
                <span className="text-xs text-gray-400">Sort: {cat.sortOrder}</span>
              </div>
            </div>
          ))
        }
      </div>

      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm px-4">
          <div className="bg-white rounded-3xl shadow-2xl w-full max-w-md animate-slide-up">
            <div className="flex items-center justify-between p-6 border-b border-gray-100">
              <h2 className="font-bold text-xl">{editCat ? 'Edit Category' : 'Add Category'}</h2>
              <button onClick={() => setShowModal(false)} className="p-2 rounded-xl hover:bg-gray-100"><FiX size={20} /></button>
            </div>
            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              <div>
                <label className="text-sm font-bold text-gray-700 mb-1.5 block">Category Name *</label>
                <input value={form.name} onChange={e => setForm(p => ({...p, name: e.target.value}))}
                  placeholder="e.g. Bhujia" className="input-field" required />
              </div>
              <div>
                <label className="text-sm font-bold text-gray-700 mb-2 block">Icon (Emoji)</label>
                <div className="flex flex-wrap gap-2 p-3 bg-gray-50 rounded-xl mb-2">
                  {EMOJI_OPTIONS.map(e => (
                    <button key={e} type="button" onClick={() => setForm(p => ({...p, icon: e}))}
                      className={`text-2xl p-1.5 rounded-lg transition-colors ${form.icon === e ? 'bg-primary-100 ring-2 ring-primary-400' : 'hover:bg-gray-200'}`}>
                      {e}
                    </button>
                  ))}
                </div>
                <input value={form.icon} onChange={e => setForm(p => ({...p, icon: e.target.value}))}
                  placeholder="Or type any emoji" className="input-field" />
              </div>
              <div>
                <label className="text-sm font-bold text-gray-700 mb-1.5 block">Description</label>
                <textarea value={form.description} onChange={e => setForm(p => ({...p, description: e.target.value}))}
                  rows={2} className="input-field resize-none" placeholder="Brief category description" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-bold text-gray-700 mb-1.5 block">Sort Order</label>
                  <input type="number" value={form.sortOrder} onChange={e => setForm(p => ({...p, sortOrder: parseInt(e.target.value)}))}
                    className="input-field" min="0" />
                </div>
                <div className="flex items-center gap-2 pt-6">
                  <input type="checkbox" id="catActive" checked={form.isActive}
                    onChange={e => setForm(p => ({...p, isActive: e.target.checked}))} className="accent-primary-500 w-4 h-4" />
                  <label htmlFor="catActive" className="text-sm font-medium text-gray-700">Active</label>
                </div>
              </div>
              <div className="flex gap-3 pt-2">
                <button type="submit" disabled={saving} className="btn-primary flex-1 py-3 disabled:opacity-70">
                  {saving ? 'Saving...' : editCat ? 'Update' : 'Create'}
                </button>
                <button type="button" onClick={() => setShowModal(false)} className="btn-secondary px-5">Cancel</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

'use client';
import { useState, useEffect } from 'react';
import { FiPlus, FiTrash2, FiEdit2, FiX } from 'react-icons/fi';
import { adminAPI } from '../../../lib/api';
import toast from 'react-hot-toast';

const EMPTY_FORM = {
  code: '', description: '', discountType: 'percentage', discountValue: '',
  minOrderAmount: '', maxDiscountAmount: '', usageLimit: '', userLimit: 1,
  isActive: true, expiresAt: '',
};

export default function AdminCouponsPage() {
  const [coupons, setCoupons] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editCoupon, setEditCoupon] = useState(null);
  const [form, setForm] = useState(EMPTY_FORM);
  const [saving, setSaving] = useState(false);

  const fetchCoupons = async () => {
    try {
      const { data } = await adminAPI.getCoupons();
      setCoupons(data.coupons);
    } catch { toast.error('Failed to load coupons'); }
    finally { setLoading(false); }
  };

  useEffect(() => { fetchCoupons(); }, []);

  const openAdd = () => { setEditCoupon(null); setForm(EMPTY_FORM); setShowModal(true); };
  const openEdit = (c) => {
    setEditCoupon(c);
    setForm({
      ...c,
      expiresAt: c.expiresAt ? new Date(c.expiresAt).toISOString().split('T')[0] : '',
    });
    setShowModal(true);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      const payload = {
        ...form,
        code: form.code.toUpperCase(),
        discountValue: Number(form.discountValue),
        minOrderAmount: Number(form.minOrderAmount) || 0,
        maxDiscountAmount: form.maxDiscountAmount ? Number(form.maxDiscountAmount) : undefined,
        usageLimit: form.usageLimit ? Number(form.usageLimit) : undefined,
        userLimit: Number(form.userLimit) || 1,
      };
      if (editCoupon) {
        const { data } = await adminAPI.updateCoupon(editCoupon._id, payload);
        setCoupons(prev => prev.map(c => c._id === editCoupon._id ? data.coupon : c));
        toast.success('Coupon updated!');
      } else {
        const { data } = await adminAPI.createCoupon(payload);
        setCoupons(prev => [data.coupon, ...prev]);
        toast.success('Coupon created!');
      }
      setShowModal(false);
    } catch (err) {
      toast.error(err.response?.data?.message || 'Save failed');
    } finally { setSaving(false); }
  };

  const handleDelete = async (id) => {
    if (!confirm('Delete this coupon?')) return;
    try {
      await adminAPI.deleteCoupon(id);
      setCoupons(prev => prev.filter(c => c._id !== id));
      toast.success('Coupon deleted');
    } catch { toast.error('Delete failed'); }
  };

  const setF = (key, val) => setForm(prev => ({ ...prev, [key]: val }));

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="font-display text-2xl font-bold text-dark">Coupons</h1>
          <p className="text-gray-500 text-sm mt-1">{coupons.length} coupons</p>
        </div>
        <button onClick={openAdd} className="btn-primary flex items-center gap-2">
          <FiPlus size={18} /> Add Coupon
        </button>
      </div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {loading ? Array(6).fill(null).map((_, i) => <div key={i} className="h-44 skeleton rounded-2xl" />) :
          coupons.map(coupon => (
            <div key={coupon._id} className={`card p-5 transition-all ${!coupon.isActive ? 'opacity-60' : ''}`}>
              <div className="flex items-start justify-between mb-3">
                <div className="font-mono font-bold text-lg text-primary-600 bg-primary-50 px-3 py-1 rounded-xl">{coupon.code}</div>
                <div className="flex gap-1">
                  <button onClick={() => openEdit(coupon)} className="p-1.5 rounded-lg hover:bg-blue-50 text-gray-400 hover:text-blue-500 transition-colors"><FiEdit2 size={14} /></button>
                  <button onClick={() => handleDelete(coupon._id)} className="p-1.5 rounded-lg hover:bg-red-50 text-gray-400 hover:text-red-500 transition-colors"><FiTrash2 size={14} /></button>
                </div>
              </div>
              <div className="text-2xl font-bold text-gray-800">
                {coupon.discountType === 'percentage' ? `${coupon.discountValue}% OFF` : `₹${coupon.discountValue} OFF`}
              </div>
              {coupon.description && <p className="text-sm text-gray-500 mt-1">{coupon.description}</p>}
              <div className="mt-3 space-y-1 text-xs text-gray-500">
                {coupon.minOrderAmount > 0 && <div>Min order: ₹{coupon.minOrderAmount}</div>}
                {coupon.maxDiscountAmount && <div>Max discount: ₹{coupon.maxDiscountAmount}</div>}
                {coupon.usageLimit && <div>Used: {coupon.usedCount}/{coupon.usageLimit}</div>}
                {coupon.expiresAt && <div>Expires: {new Date(coupon.expiresAt).toLocaleDateString('en-IN')}</div>}
              </div>
              <div className="flex items-center gap-2 mt-3 pt-3 border-t border-gray-100">
                <span className={`badge text-xs ${coupon.isActive ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-600'}`}>
                  {coupon.isActive ? 'Active' : 'Inactive'}
                </span>
                <span className="badge bg-gray-100 text-gray-600 text-xs capitalize">{coupon.discountType}</span>
              </div>
            </div>
          ))
        }
      </div>

      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm px-4 overflow-y-auto py-6">
          <div className="bg-white rounded-3xl shadow-2xl w-full max-w-lg animate-slide-up">
            <div className="flex items-center justify-between p-6 border-b border-gray-100">
              <h2 className="font-bold text-xl">{editCoupon ? 'Edit Coupon' : 'New Coupon'}</h2>
              <button onClick={() => setShowModal(false)} className="p-2 rounded-xl hover:bg-gray-100"><FiX size={20} /></button>
            </div>
            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              <div className="grid sm:grid-cols-2 gap-4">
                <div className="sm:col-span-2">
                  <label className="text-sm font-bold text-gray-700 mb-1.5 block">Coupon Code *</label>
                  <input value={form.code} onChange={e => setF('code', e.target.value.toUpperCase())}
                    placeholder="WELCOME10" className="input-field font-mono font-bold uppercase" required />
                </div>
                <div>
                  <label className="text-sm font-bold text-gray-700 mb-1.5 block">Discount Type *</label>
                  <select value={form.discountType} onChange={e => setF('discountType', e.target.value)} className="input-field">
                    <option value="percentage">Percentage (%)</option>
                    <option value="fixed">Fixed Amount (₹)</option>
                  </select>
                </div>
                <div>
                  <label className="text-sm font-bold text-gray-700 mb-1.5 block">
                    Discount Value * {form.discountType === 'percentage' ? '(%)' : '(₹)'}
                  </label>
                  <input type="number" value={form.discountValue} onChange={e => setF('discountValue', e.target.value)}
                    placeholder={form.discountType === 'percentage' ? '10' : '50'} className="input-field" required min="1" />
                </div>
                <div>
                  <label className="text-sm font-bold text-gray-700 mb-1.5 block">Min Order Amount (₹)</label>
                  <input type="number" value={form.minOrderAmount} onChange={e => setF('minOrderAmount', e.target.value)}
                    placeholder="200" className="input-field" min="0" />
                </div>
                {form.discountType === 'percentage' && (
                  <div>
                    <label className="text-sm font-bold text-gray-700 mb-1.5 block">Max Discount Cap (₹)</label>
                    <input type="number" value={form.maxDiscountAmount} onChange={e => setF('maxDiscountAmount', e.target.value)}
                      placeholder="100" className="input-field" min="0" />
                  </div>
                )}
                <div>
                  <label className="text-sm font-bold text-gray-700 mb-1.5 block">Usage Limit (total)</label>
                  <input type="number" value={form.usageLimit} onChange={e => setF('usageLimit', e.target.value)}
                    placeholder="Unlimited" className="input-field" min="1" />
                </div>
                <div>
                  <label className="text-sm font-bold text-gray-700 mb-1.5 block">Per User Limit</label>
                  <input type="number" value={form.userLimit} onChange={e => setF('userLimit', e.target.value)}
                    placeholder="1" className="input-field" min="1" />
                </div>
                <div>
                  <label className="text-sm font-bold text-gray-700 mb-1.5 block">Expiry Date</label>
                  <input type="date" value={form.expiresAt} onChange={e => setF('expiresAt', e.target.value)} className="input-field" />
                </div>
              </div>
              <div>
                <label className="text-sm font-bold text-gray-700 mb-1.5 block">Description</label>
                <input value={form.description} onChange={e => setF('description', e.target.value)}
                  placeholder="e.g. Welcome offer for new users" className="input-field" />
              </div>
              <div className="flex items-center gap-2">
                <input type="checkbox" id="couponActive" checked={form.isActive}
                  onChange={e => setF('isActive', e.target.checked)} className="accent-primary-500 w-4 h-4" />
                <label htmlFor="couponActive" className="text-sm font-medium text-gray-700">Active</label>
              </div>
              <div className="flex gap-3 pt-2">
                <button type="submit" disabled={saving} className="btn-primary flex-1 py-3 disabled:opacity-70">
                  {saving ? 'Saving...' : editCoupon ? 'Update Coupon' : 'Create Coupon'}
                </button>
                <button type="button" onClick={() => setShowModal(false)} className="btn-secondary px-5">Cancel</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

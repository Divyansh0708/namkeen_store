'use client';
import { useEffect, useState } from 'react';
import { useParams, useSearchParams, useRouter } from 'next/navigation';
import Link from 'next/link';
import { FiCheck, FiPackage, FiTruck, FiHome, FiX } from 'react-icons/fi';
import { orderAPI } from '../../../lib/api';
import { useAuth } from '../../../context/AuthContext';
import toast from 'react-hot-toast';

const TRACK_STEPS = [
  { key: 'placed',    icon: FiPackage,  label: 'Order Placed' },
  { key: 'confirmed', icon: FiCheck,    label: 'Confirmed' },
  { key: 'shipped',   icon: FiTruck,    label: 'Shipped' },
  { key: 'delivered', icon: FiHome,     label: 'Delivered' },
];

const STATUS_STEP = { placed: 0, confirmed: 1, processing: 1, shipped: 2, delivered: 3, cancelled: -1 };

export default function OrderDetailPage() {
  const { id } = useParams();
  const searchParams = useSearchParams();
  const router = useRouter();
  const { isLoggedIn } = useAuth();
  const [order, setOrder] = useState(null);
  const [loading, setLoading] = useState(true);
  const [cancelling, setCancelling] = useState(false);
  const success = searchParams.get('success');

  useEffect(() => {
    if (!isLoggedIn) { router.push('/auth/login'); return; }
    orderAPI.getOne(id).then(({ data }) => setOrder(data.order)).finally(() => setLoading(false));
  }, [id, isLoggedIn, router]);

  const handleCancel = async () => {
    if (!confirm('Are you sure you want to cancel this order?')) return;
    setCancelling(true);
    try {
      const { data } = await orderAPI.cancel(id);
      setOrder(data.order);
      toast.success('Order cancelled successfully');
    } catch (err) {
      toast.error(err.response?.data?.message || 'Cannot cancel order');
    } finally {
      setCancelling(false);
    }
  };

  if (loading) return (
    <div className="min-h-screen flex items-center justify-center">
      <div className="w-10 h-10 border-4 border-primary-200 border-t-primary-500 rounded-full animate-spin" />
    </div>
  );

  if (!order) return null;

  const currentStep = STATUS_STEP[order.orderStatus] ?? 0;
  const isCancelled = order.orderStatus === 'cancelled';
  const canCancel = ['placed', 'confirmed'].includes(order.orderStatus);

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="container-custom max-w-4xl">
        {/* Success banner */}
        {success && (
          <div className="bg-green-50 border border-green-200 rounded-2xl p-5 mb-6 flex items-center gap-4 animate-slide-up">
            <div className="w-12 h-12 bg-green-500 rounded-full flex items-center justify-center flex-shrink-0">
              <FiCheck className="text-white" size={22} />
            </div>
            <div>
              <div className="font-bold text-green-800 text-lg">Order Placed Successfully! 🎉</div>
              <div className="text-green-600 text-sm">You'll receive a confirmation email shortly. Estimated delivery: 3–5 business days.</div>
            </div>
          </div>
        )}

        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="font-display text-2xl font-bold text-dark">Order #{order.orderNumber}</h1>
            <p className="text-gray-500 text-sm mt-1">
              Placed on {new Date(order.createdAt).toLocaleDateString('en-IN', { day: 'numeric', month: 'long', year: 'numeric', hour: '2-digit', minute: '2-digit' })}
            </p>
          </div>
          {canCancel && (
            <button onClick={handleCancel} disabled={cancelling}
              className="flex items-center gap-2 px-4 py-2 border border-red-200 text-red-500 hover:bg-red-50 rounded-xl text-sm font-semibold transition-colors disabled:opacity-60">
              <FiX size={14} /> {cancelling ? 'Cancelling...' : 'Cancel Order'}
            </button>
          )}
        </div>

        <div className="grid lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-5">
            {/* Tracking */}
            {!isCancelled && (
              <div className="card p-6">
                <h2 className="font-bold text-gray-800 mb-6">Order Tracking</h2>
                <div className="relative">
                  <div className="absolute left-6 top-6 bottom-6 w-0.5 bg-gray-200" />
                  <div className="space-y-6">
                    {TRACK_STEPS.map((step, i) => {
                      const done = i <= currentStep;
                      const active = i === currentStep;
                      const Icon = step.icon;
                      const historyEntry = order.statusHistory?.find(h => h.status === step.key);
                      return (
                        <div key={step.key} className="flex gap-4 relative">
                          <div className={`w-12 h-12 rounded-full flex items-center justify-center flex-shrink-0 z-10 transition-all ${
                            done ? 'bg-primary-500 text-white shadow-orange' : 'bg-white border-2 border-gray-200 text-gray-400'
                          } ${active ? 'scale-110' : ''}`}>
                            <Icon size={18} />
                          </div>
                          <div className="flex-1 pt-2">
                            <div className={`font-bold ${done ? 'text-gray-800' : 'text-gray-400'}`}>{step.label}</div>
                            {historyEntry && (
                              <div className="text-xs text-gray-500 mt-0.5">
                                {new Date(historyEntry.timestamp).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}
                                {historyEntry.note && ` · ${historyEntry.note}`}
                              </div>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
                {order.trackingNumber && (
                  <div className="mt-4 p-3 bg-blue-50 rounded-xl text-sm text-blue-700">
                    <span className="font-semibold">Tracking ID:</span> {order.trackingNumber}
                  </div>
                )}
              </div>
            )}

            {isCancelled && (
              <div className="card p-6 border-2 border-red-100">
                <div className="flex items-center gap-3 text-red-500">
                  <FiX size={24} />
                  <div>
                    <div className="font-bold text-lg">Order Cancelled</div>
                    <div className="text-sm text-red-400">This order has been cancelled. Refund (if any) will be processed in 5–7 business days.</div>
                  </div>
                </div>
              </div>
            )}

            {/* Items */}
            <div className="card p-6">
              <h2 className="font-bold text-gray-800 mb-4">Order Items</h2>
              <div className="space-y-4">
                {order.items.map((item, i) => (
                  <div key={i} className="flex gap-4 py-3 border-b border-gray-50 last:border-0">
                    <div className="w-16 h-16 rounded-xl overflow-hidden bg-gray-100 flex-shrink-0">
                      {item.image && <img src={item.image} alt={item.name} className="w-full h-full object-cover" />}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="font-semibold text-gray-800 line-clamp-1">{item.name}</div>
                      <div className="text-sm text-gray-500 mt-0.5">₹{item.price} × {item.quantity}</div>
                    </div>
                    <div className="font-bold text-gray-900 flex-shrink-0">₹{(item.price * item.quantity).toFixed(2)}</div>
                  </div>
                ))}
              </div>
            </div>

            {/* Delivery address */}
            <div className="card p-6">
              <h2 className="font-bold text-gray-800 mb-3">Delivery Address</h2>
              <div className="text-gray-600 text-sm leading-relaxed">
                <div className="font-semibold text-gray-800">{order.shippingAddress.name}</div>
                <div>{order.shippingAddress.phone}</div>
                <div>{order.shippingAddress.street}</div>
                <div>{order.shippingAddress.city}, {order.shippingAddress.state} — {order.shippingAddress.pincode}</div>
              </div>
            </div>
          </div>

          {/* Summary */}
          <div className="space-y-5">
            <div className="card p-5">
              <h3 className="font-bold text-gray-800 mb-4">Payment Summary</h3>
              <div className="space-y-2.5 text-sm">
                <div className="flex justify-between text-gray-600"><span>Subtotal</span><span>₹{order.itemsPrice.toFixed(2)}</span></div>
                {order.discountAmount > 0 && <div className="flex justify-between text-green-600"><span>Discount</span><span>-₹{order.discountAmount}</span></div>}
                <div className="flex justify-between text-gray-600"><span>GST</span><span>₹{order.taxPrice.toFixed(2)}</span></div>
                <div className="flex justify-between text-gray-600"><span>Shipping</span><span className={order.shippingPrice === 0 ? 'text-green-600 font-semibold' : ''}>{order.shippingPrice === 0 ? 'FREE' : `₹${order.shippingPrice}`}</span></div>
                <div className="flex justify-between font-bold text-base pt-2 border-t border-gray-100">
                  <span>Total</span><span className="text-primary-600">₹{order.totalPrice.toFixed(2)}</span>
                </div>
              </div>
              <div className="mt-4 flex flex-col gap-2 text-xs">
                <div className="flex justify-between">
                  <span className="text-gray-500">Payment Method</span>
                  <span className="font-semibold capitalize">{order.paymentMethod === 'cod' ? 'Cash on Delivery' : 'Online Payment'}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">Payment Status</span>
                  <span className={`font-semibold capitalize ${order.paymentStatus === 'paid' ? 'text-green-600' : 'text-orange-500'}`}>{order.paymentStatus}</span>
                </div>
              </div>
            </div>

            <Link href="/products" className="btn-primary w-full text-center block">Continue Shopping</Link>
            <Link href="/orders" className="btn-secondary w-full text-center block text-sm">← All Orders</Link>
          </div>
        </div>
      </div>
    </div>
  );
}

'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import { useSearchParams } from 'next/navigation';
import { FiPackage, FiChevronRight, FiCheck } from 'react-icons/fi';
import { orderAPI } from '../../lib/api';
import { useAuth } from '../../context/AuthContext';

const STATUS_CONFIG = {
  placed:      { color: 'bg-blue-100 text-blue-700',    label: 'Order Placed',   step: 1 },
  confirmed:   { color: 'bg-indigo-100 text-indigo-700', label: 'Confirmed',      step: 2 },
  processing:  { color: 'bg-yellow-100 text-yellow-700', label: 'Processing',     step: 2 },
  shipped:     { color: 'bg-orange-100 text-orange-700', label: 'Shipped',        step: 3 },
  delivered:   { color: 'bg-green-100 text-green-700',   label: 'Delivered',      step: 4 },
  cancelled:   { color: 'bg-red-100 text-red-700',       label: 'Cancelled',      step: 0 },
  returned:    { color: 'bg-gray-100 text-gray-700',     label: 'Returned',       step: 0 },
};

export default function OrdersPage() {
  const { isLoggedIn } = useAuth();
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!isLoggedIn) return;
    orderAPI.getMyOrders().then(({ data }) => setOrders(data.orders)).finally(() => setLoading(false));
  }, [isLoggedIn]);

  if (!isLoggedIn) return (
    <div className="min-h-screen flex items-center justify-center">
      <div className="text-center">
        <div className="text-6xl mb-4">📦</div>
        <Link href="/auth/login?redirect=/orders" className="btn-primary">Login to View Orders</Link>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="container-custom max-w-4xl">
        <h1 className="font-display text-3xl font-bold text-dark mb-8">My Orders</h1>
        {loading ? (
          <div className="space-y-4">{Array(3).fill(null).map((_, i) => <div key={i} className="h-32 skeleton rounded-2xl" />)}</div>
        ) : orders.length === 0 ? (
          <div className="text-center py-20">
            <div className="text-6xl mb-4">📦</div>
            <h3 className="font-bold text-xl text-gray-700 mb-2">No orders yet</h3>
            <p className="text-gray-500 mb-6">Start shopping to see your orders here</p>
            <Link href="/products" className="btn-primary">Shop Now</Link>
          </div>
        ) : (
          <div className="space-y-4">
            {orders.map((order) => {
              const conf = STATUS_CONFIG[order.orderStatus] || STATUS_CONFIG.placed;
              return (
                <Link key={order._id} href={`/orders/${order._id}`}
                  className="card p-5 flex flex-col sm:flex-row items-start sm:items-center gap-4 hover:shadow-card-hover transition-all group">
                  <div className="w-12 h-12 bg-primary-100 rounded-2xl flex items-center justify-center flex-shrink-0">
                    <FiPackage className="text-primary-600" size={22} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="font-bold text-gray-800">#{order.orderNumber}</span>
                      <span className={`badge text-xs ${conf.color}`}>{conf.label}</span>
                    </div>
                    <div className="text-sm text-gray-500 mt-1">
                      {new Date(order.createdAt).toLocaleDateString('en-IN', { day: 'numeric', month: 'long', year: 'numeric' })}
                      {' · '}{order.items.length} item{order.items.length > 1 ? 's' : ''}
                    </div>
                    <div className="text-sm text-gray-600 mt-1 line-clamp-1">
                      {order.items.map(i => i.name).join(', ')}
                    </div>
                  </div>
                  <div className="flex flex-col items-end gap-2 flex-shrink-0">
                    <span className="font-extrabold text-lg text-gray-900">₹{order.totalPrice.toFixed(2)}</span>
                    <span className="text-xs text-gray-400 capitalize">{order.paymentMethod === 'cod' ? 'Cash on Delivery' : 'Online Payment'}</span>
                  </div>
                  <FiChevronRight className="text-gray-400 group-hover:text-primary-500 transition-colors hidden sm:block" />
                </Link>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}

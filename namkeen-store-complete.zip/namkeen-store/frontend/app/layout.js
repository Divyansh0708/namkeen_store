import { Toaster } from 'react-hot-toast';
import { AuthProvider } from '../context/AuthContext';
import { CartProvider } from '../context/CartContext';
import Navbar from '../components/layout/Navbar';
import Footer from '../components/layout/Footer';
import WhatsAppButton from '../components/common/WhatsAppButton';
import '../styles/globals.css';

export const metadata = {
  title: {
    default: 'Namkeen Store — Premium Indian Snacks',
    template: '%s | Namkeen Store',
  },
  description: 'Shop the finest collection of authentic Indian namkeens — Bhujia, Sev, Mixture, Chips & more. Fresh, crispy, and packed with traditional flavors.',
  keywords: 'namkeen, bhujia, sev, mixture, indian snacks, chips, healthy snacks, traditional snacks',
  openGraph: {
    title: 'Namkeen Store — Premium Indian Snacks',
    description: 'Authentic Indian namkeens delivered to your doorstep.',
    type: 'website',
  },
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <head>
        <link rel="icon" href="/favicon.ico" />
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
      </head>
      <body>
        <AuthProvider>
          <CartProvider>
            <div className="min-h-screen flex flex-col">
              <Navbar />
              <main className="flex-1">{children}</main>
              <Footer />
            </div>
            <WhatsAppButton />
            <Toaster
              position="top-right"
              toastOptions={{
                duration: 3000,
                style: { fontFamily: 'Nunito, sans-serif', fontWeight: '600' },
                success: { iconTheme: { primary: '#e67e22', secondary: '#fff' } },
              }}
            />
          </CartProvider>
        </AuthProvider>
      </body>
    </html>
  );
}

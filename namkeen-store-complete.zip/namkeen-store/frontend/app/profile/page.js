'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { FiUser, FiMail, FiPhone, FiLock, FiMapPin, FiPlus, FiEdit2, FiTrash2 } from 'react-icons/fi';
import { useAuth } from '../../context/AuthContext';
import { authAPI } from '../../lib/api';
import toast from 'react-hot-toast';

const INDIAN_STATES = ['Andhra Pradesh','Assam','Bihar','Chhattisgarh','Delhi','Goa','Gujarat','Haryana','Himachal Pradesh','Jharkhand','Karnataka','Kerala','Madhya Pradesh','Maharashtra','Manipur','Meghalaya','Mizoram','Nagaland','Odisha','Punjab','Rajasthan','Sikkim','Tamil Nadu','Telangana','Tripura','Uttar Pradesh','Uttarakhand','West Bengal'];

export default function ProfilePage() {
  const { user, updateUser, isLoggedIn, logout } = useAuth();
  const router = useRouter();
  const [activeTab, setActiveTab] = useState('profile');
  const [saving, setSaving] = useState(false);

  const [profileForm, setProfileForm] = useState({ name: user?.name || '', phone: user?.phone || '' });
  const [pwForm, setPwForm] = useState({ currentPassword: '', newPassword: '', confirmPassword: '' });
  const [showAddrForm, setShowAddrForm] = useState(false);
  const [addrForm, setAddrForm] = useState({ name: '', phone: '', street: '', city: '', state: '', pincode: '', isDefault: false });

  if (!isLoggedIn) { router.push('/auth/login'); return null; }

  const handleProfileUpdate = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      const { data } = await authAPI.updateProfile(profileForm);
      updateUser(data.user);
      toast.success('Profile updated!');
    } catch (err) {
      toast.error(err.response?.data?.message || 'Update failed');
    } finally { setSaving(false); }
  };

  const handlePasswordChange = async (e) => {
    e.preventDefault();
    if (pwForm.newPassword !== pwForm.confirmPassword) { toast.error('Passwords do not match'); return; }
    if (pwForm.newPassword.length < 6) { toast.error('New password must be at least 6 characters'); return; }
    setSaving(true);
    try {
      await authAPI.changePassword({ currentPassword: pwForm.currentPassword, newPassword: pwForm.newPassword });
      toast.success('Password updated successfully!');
      setPwForm({ currentPassword: '', newPassword: '', confirmPassword: '' });
    } catch (err) {
      toast.error(err.response?.data?.message || 'Password change failed');
    } finally { setSaving(false); }
  };

  const handleAddAddress = async (e) => {
    e.preventDefault();
    try {
      const { data } = await authAPI.addAddress(addrForm);
      updateUser({ ...user, addresses: data.addresses });
      setShowAddrForm(false);
      setAddrForm({ name: '', phone: '', street: '', city: '', state: '', pincode: '', isDefault: false });
      toast.success('Address added!');
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to add address');
    }
  };

  const handleDeleteAddress = async (addrId) => {
    if (!confirm('Delete this address?')) return;
    try {
      const { data } = await authAPI.deleteAddress(addrId);
      updateUser({ ...user, addresses: data.addresses });
      toast.success('Address removed');
    } catch { toast.error('Failed to delete address'); }
  };

  const tabs = [
    { id: 'profile', icon: FiUser, label: 'Profile' },
    { id: 'security', icon: FiLock, label: 'Security' },
    { id: 'addresses', icon: FiMapPin, label: 'Addresses' },
  ];

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="container-custom max-w-4xl">
        <div className="flex items-center gap-4 mb-8">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-primary-400 to-primary-600 flex items-center justify-center text-white font-bold text-2xl shadow-orange">
            {user?.name?.charAt(0).toUpperCase()}
          </div>
          <div>
            <h1 className="font-display text-2xl font-bold text-dark">{user?.name}</h1>
            <p className="text-gray-500">{user?.email}</p>
          </div>
        </div>

        <div className="grid md:grid-cols-4 gap-6">
          {/* Sidebar */}
          <div className="md:col-span-1">
            <div className="card p-2 space-y-1">
              {tabs.map(({ id, icon: Icon, label }) => (
                <button key={id} onClick={() => setActiveTab(id)}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl font-semibold text-sm transition-colors ${
                    activeTab === id ? 'bg-primary-500 text-white' : 'text-gray-600 hover:bg-gray-50'
                  }`}>
                  <Icon size={16} /> {label}
                </button>
              ))}
              <div className="border-t border-gray-100 pt-1 mt-1">
                <button onClick={logout}
                  className="w-full flex items-center gap-3 px-4 py-3 rounded-xl font-semibold text-sm text-red-500 hover:bg-red-50 transition-colors">
                  Sign Out
                </button>
              </div>
            </div>
          </div>

          {/* Content */}
          <div className="md:col-span-3">
            {activeTab === 'profile' && (
              <div className="card p-6">
                <h2 className="font-bold text-lg text-gray-800 mb-5">Personal Information</h2>
                <form onSubmit={handleProfileUpdate} className="space-y-4">
                  <div>
                    <label className="text-sm font-semibold text-gray-700 mb-1.5 block">Full Name</label>
                    <div className="relative">
                      <FiUser className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={16} />
                      <input value={profileForm.name} onChange={(e) => setProfileForm(p => ({...p, name: e.target.value}))}
                        placeholder="Your name" className="input-field pl-11" required />
                    </div>
                  </div>
                  <div>
                    <label className="text-sm font-semibold text-gray-700 mb-1.5 block">Email (read-only)</label>
                    <div className="relative">
                      <FiMail className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={16} />
                      <input value={user?.email} className="input-field pl-11 bg-gray-50" disabled />
                    </div>
                  </div>
                  <div>
                    <label className="text-sm font-semibold text-gray-700 mb-1.5 block">Phone Number</label>
                    <div className="relative">
                      <FiPhone className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={16} />
                      <input value={profileForm.phone} onChange={(e) => setProfileForm(p => ({...p, phone: e.target.value}))}
                        placeholder="9876543210" className="input-field pl-11" />
                    </div>
                  </div>
                  <button type="submit" disabled={saving} className="btn-primary py-3 px-8 disabled:opacity-70">
                    {saving ? 'Saving...' : 'Save Changes'}
                  </button>
                </form>
              </div>
            )}

            {activeTab === 'security' && (
              <div className="card p-6">
                <h2 className="font-bold text-lg text-gray-800 mb-5">Change Password</h2>
                <form onSubmit={handlePasswordChange} className="space-y-4 max-w-sm">
                  {[
                    { key: 'currentPassword', label: 'Current Password', placeholder: 'Enter current password' },
                    { key: 'newPassword', label: 'New Password', placeholder: 'Min 6 characters' },
                    { key: 'confirmPassword', label: 'Confirm Password', placeholder: 'Repeat new password' },
                  ].map(({ key, label, placeholder }) => (
                    <div key={key}>
                      <label className="text-sm font-semibold text-gray-700 mb-1.5 block">{label}</label>
                      <div className="relative">
                        <FiLock className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={16} />
                        <input type="password" value={pwForm[key]} onChange={(e) => setPwForm(p => ({...p, [key]: e.target.value}))}
                          placeholder={placeholder} className="input-field pl-11" required />
                      </div>
                    </div>
                  ))}
                  <button type="submit" disabled={saving} className="btn-primary py-3 px-8 disabled:opacity-70">
                    {saving ? 'Updating...' : 'Update Password'}
                  </button>
                </form>
              </div>
            )}

            {activeTab === 'addresses' && (
              <div className="card p-6">
                <div className="flex items-center justify-between mb-5">
                  <h2 className="font-bold text-lg text-gray-800">Saved Addresses</h2>
                  <button onClick={() => setShowAddrForm(!showAddrForm)} className="btn-primary py-2 px-4 text-sm flex items-center gap-2">
                    <FiPlus size={14} /> Add Address
                  </button>
                </div>

                {showAddrForm && (
                  <form onSubmit={handleAddAddress} className="mb-6 p-5 bg-gray-50 rounded-2xl space-y-4">
                    <h4 className="font-semibold text-gray-700">New Address</h4>
                    <div className="grid sm:grid-cols-2 gap-4">
                      {[
                        { key: 'name', label: 'Full Name', placeholder: 'Rajesh Kumar' },
                        { key: 'phone', label: 'Phone', placeholder: '9876543210' },
                      ].map(({ key, label, placeholder }) => (
                        <div key={key}>
                          <label className="text-sm font-semibold text-gray-700 mb-1 block">{label} *</label>
                          <input value={addrForm[key]} onChange={(e) => setAddrForm(p => ({...p, [key]: e.target.value}))}
                            placeholder={placeholder} className="input-field" required />
                        </div>
                      ))}
                    </div>
                    <div>
                      <label className="text-sm font-semibold text-gray-700 mb-1 block">Street Address *</label>
                      <input value={addrForm.street} onChange={(e) => setAddrForm(p => ({...p, street: e.target.value}))}
                        placeholder="House no, Building, Street" className="input-field" required />
                    </div>
                    <div className="grid sm:grid-cols-3 gap-4">
                      <div>
                        <label className="text-sm font-semibold text-gray-700 mb-1 block">City *</label>
                        <input value={addrForm.city} onChange={(e) => setAddrForm(p => ({...p, city: e.target.value}))}
                          placeholder="Bikaner" className="input-field" required />
                      </div>
                      <div>
                        <label className="text-sm font-semibold text-gray-700 mb-1 block">Pincode *</label>
                        <input value={addrForm.pincode} onChange={(e) => setAddrForm(p => ({...p, pincode: e.target.value}))}
                          placeholder="334001" className="input-field" required />
                      </div>
                      <div>
                        <label className="text-sm font-semibold text-gray-700 mb-1 block">State *</label>
                        <select value={addrForm.state} onChange={(e) => setAddrForm(p => ({...p, state: e.target.value}))} className="input-field" required>
                          <option value="">Select</option>
                          {INDIAN_STATES.map(s => <option key={s} value={s}>{s}</option>)}
                        </select>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <input type="checkbox" id="default" checked={addrForm.isDefault}
                        onChange={(e) => setAddrForm(p => ({...p, isDefault: e.target.checked}))} className="accent-primary-500" />
                      <label htmlFor="default" className="text-sm font-medium text-gray-600">Set as default address</label>
                    </div>
                    <div className="flex gap-3">
                      <button type="submit" className="btn-primary py-2.5 flex-1">Save Address</button>
                      <button type="button" onClick={() => setShowAddrForm(false)} className="btn-secondary py-2.5 px-4">Cancel</button>
                    </div>
                  </form>
                )}

                {user?.addresses?.length === 0 ? (
                  <div className="text-center py-8 text-gray-400">
                    <div className="text-4xl mb-2">📍</div>
                    <p>No saved addresses yet</p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {user?.addresses?.map((addr) => (
                      <div key={addr._id} className="p-4 border border-gray-200 rounded-2xl flex items-start justify-between gap-3">
                        <div className="flex gap-3">
                          <FiMapPin className="text-primary-500 mt-1 flex-shrink-0" size={16} />
                          <div>
                            <div className="font-semibold text-gray-800">{addr.name} <span className="text-gray-400 font-normal text-sm">• {addr.phone}</span></div>
                            <div className="text-sm text-gray-600 mt-0.5">{addr.street}, {addr.city}, {addr.state} — {addr.pincode}</div>
                            {addr.isDefault && <span className="text-xs bg-primary-100 text-primary-700 px-2 py-0.5 rounded-full font-semibold mt-1 inline-block">Default</span>}
                          </div>
                        </div>
                        <button onClick={() => handleDeleteAddress(addr._id)}
                          className="p-2 rounded-lg hover:bg-red-50 text-gray-400 hover:text-red-500 transition-colors flex-shrink-0">
                          <FiTrash2 size={15} />
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { FiArrowRight, FiStar, FiTruck, FiShield, FiRefreshCw, FiPhone } from 'react-icons/fi';
import ProductCard from '../components/product/ProductCard';
import { productAPI, categoryAPI } from '../lib/api';
import { ProductCardSkeleton } from '../components/common/Skeletons';

export default function HomePage() {
  const [featured, setFeatured] = useState([]);
  const [bestSellers, setBestSellers] = useState([]);
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [prodRes, catRes] = await Promise.all([
          productAPI.getFeatured(),
          categoryAPI.getAll(),
        ]);
        setFeatured(prodRes.data.featured);
        setBestSellers(prodRes.data.bestSellers);
        setCategories(catRes.data.categories);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, []);

  return (
    <div className="animate-fade-in">
      {/* ─── HERO SECTION ─── */}
      <section className="relative min-h-[90vh] flex items-center overflow-hidden bg-gradient-to-br from-amber-50 via-orange-50 to-red-50">
        {/* Background pattern */}
        <div className="absolute inset-0 opacity-5" style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23e67e22' fill-opacity='1'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`
        }} />

        <div className="container-custom relative z-10 py-20">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="animate-slide-up">
              <div className="inline-flex items-center gap-2 bg-primary-100 text-primary-700 px-4 py-2 rounded-full text-sm font-bold mb-6">
                <span>🌟</span> India's Favourite Namkeen Brand
              </div>
              <h1 className="font-display text-5xl md:text-6xl lg:text-7xl font-bold text-dark leading-[1.1] mb-6">
                Taste the
                <span className="block text-transparent bg-clip-text bg-gradient-to-r from-primary-500 to-amber-500">
                  Crispy Magic
                </span>
                of India
              </h1>
              <p className="text-lg text-gray-600 mb-8 max-w-lg leading-relaxed">
                Handcrafted namkeens made from authentic recipes, the finest ingredients, and generations of snacking tradition. Fresh, crispy, and bursting with flavor.
              </p>
              <div className="flex flex-wrap gap-4">
                <Link href="/products" className="btn-primary flex items-center gap-2 text-base px-8 py-4">
                  Shop Now <FiArrowRight />
                </Link>
                <Link href="/products?isBestSeller=true" className="btn-outline flex items-center gap-2 text-base px-8 py-4">
                  Best Sellers
                </Link>
              </div>
              {/* Trust badges */}
              <div className="mt-10 flex flex-wrap gap-6">
                {[
                  { icon: '🚚', label: 'Free Delivery', sub: 'Above ₹499' },
                  { icon: '✅', label: '100% Fresh', sub: 'Guaranteed' },
                  { icon: '🏆', label: 'Award Winning', sub: 'Since 2010' },
                ].map(({ icon, label, sub }) => (
                  <div key={label} className="flex items-center gap-2">
                    <span className="text-2xl">{icon}</span>
                    <div>
                      <div className="font-bold text-gray-800 text-sm">{label}</div>
                      <div className="text-xs text-gray-500">{sub}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Hero image collage */}
            <div className="relative hidden lg:block">
              <div className="relative w-full aspect-square max-w-lg mx-auto">
                <div className="absolute inset-0 bg-gradient-to-br from-primary-400/20 to-amber-400/20 rounded-[3rem] rotate-6" />
                <div className="relative rounded-[3rem] overflow-hidden shadow-2xl">
                  <Image
                    src="https://images.unsplash.com/photo-1601050690597-df0568f70950?w=700"
                    alt="Premium Namkeen"
                    width={700}
                    height={700}
                    className="object-cover w-full h-full"
                    priority
                  />
                </div>
                {/* Floating cards */}
                <div className="absolute -top-4 -right-4 bg-white rounded-2xl shadow-xl p-4 flex items-center gap-3 animate-bounce-gentle">
                  <div className="text-3xl">⭐</div>
                  <div>
                    <div className="font-bold text-gray-800 text-sm">4.9 Rating</div>
                    <div className="text-xs text-gray-500">50k+ Reviews</div>
                  </div>
                </div>
                <div className="absolute -bottom-4 -left-4 bg-white rounded-2xl shadow-xl p-4 flex items-center gap-3">
                  <div className="text-3xl">🍿</div>
                  <div>
                    <div className="font-bold text-gray-800 text-sm">100+ Varieties</div>
                    <div className="text-xs text-gray-500">Fresh Every Day</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ─── FEATURES STRIP ─── */}
      <section className="bg-primary-600 py-6">
        <div className="container-custom">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[
              { icon: FiTruck, title: 'Free Shipping', desc: 'Orders above ₹499' },
              { icon: FiShield, title: 'Secure Payment', desc: 'Razorpay encrypted' },
              { icon: FiRefreshCw, title: 'Easy Returns', desc: '7-day return policy' },
              { icon: FiPhone, title: '24/7 Support', desc: 'Always here to help' },
            ].map(({ icon: Icon, title, desc }) => (
              <div key={title} className="flex items-center gap-3 text-white">
                <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center flex-shrink-0">
                  <Icon size={18} />
                </div>
                <div>
                  <div className="font-bold text-sm">{title}</div>
                  <div className="text-xs text-primary-100">{desc}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ─── CATEGORIES ─── */}
      <section className="py-16 bg-cream">
        <div className="container-custom">
          <div className="text-center mb-10">
            <h2 className="section-title">Shop By Category</h2>
            <p className="text-gray-500 mt-3 max-w-xl mx-auto">From classic Bhujia to healthy Makhana — explore our full range of authentic Indian snacks</p>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-4">
            {(loading ? Array(8).fill(null) : categories).map((cat, i) => (
              cat ? (
                <Link key={cat._id} href={`/products?category=${cat._id}`}
                  className="group flex flex-col items-center gap-3 p-4 bg-white rounded-2xl hover:bg-primary-50 border border-transparent hover:border-primary-200 transition-all duration-200 shadow-sm hover:shadow-md text-center">
                  <div className="text-4xl group-hover:scale-110 transition-transform duration-200">{cat.icon}</div>
                  <span className="text-sm font-bold text-gray-700 group-hover:text-primary-600 leading-tight">{cat.name}</span>
                </Link>
              ) : (
                <div key={i} className="rounded-2xl h-28 skeleton" />
              )
            ))}
          </div>
        </div>
      </section>

      {/* ─── FEATURED PRODUCTS ─── */}
      <section className="py-16">
        <div className="container-custom">
          <div className="flex items-center justify-between mb-8">
            <div>
              <h2 className="section-title">Featured Products</h2>
              <p className="text-gray-500 mt-1">Handpicked by our snack experts</p>
            </div>
            <Link href="/products?isFeatured=true" className="btn-outline py-2 px-5 text-sm hidden md:flex items-center gap-2">
              View All <FiArrowRight />
            </Link>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6">
            {loading
              ? Array(8).fill(null).map((_, i) => <ProductCardSkeleton key={i} />)
              : featured.map((p) => <ProductCard key={p._id} product={p} />)
            }
          </div>
          <div className="text-center mt-8 md:hidden">
            <Link href="/products?isFeatured=true" className="btn-outline">View All Featured</Link>
          </div>
        </div>
      </section>

      {/* ─── PROMO BANNER ─── */}
      <section className="py-8">
        <div className="container-custom">
          <div className="relative bg-gradient-to-r from-primary-600 via-primary-500 to-amber-500 rounded-3xl overflow-hidden p-8 md:p-12">
            <div className="absolute inset-0 opacity-10" style={{backgroundImage: 'url("data:image/svg+xml,%3Csvg width=\'40\' height=\'40\' viewBox=\'0 0 40 40\' xmlns=\'http://www.w3.org/2000/svg\'%3E%3Cg fill=\'%23fff\' fill-opacity=\'1\' fill-rule=\'evenodd\'%3E%3Cpath d=\'m0 40 40-40H20L0 20M40 40V20L20 40\'/%3E%3C/g%3E%3C/svg%3E")'}} />
            <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-6 text-white">
              <div>
                <div className="text-sm font-bold uppercase tracking-widest text-primary-100 mb-2">Limited Time Offer</div>
                <h3 className="font-display text-3xl md:text-4xl font-bold mb-2">Get 20% Off Sitewide</h3>
                <p className="text-primary-100 text-lg">Use code <strong className="bg-white/20 px-2 py-0.5 rounded text-white">DIWALI20</strong> at checkout</p>
              </div>
              <Link href="/products" className="bg-white text-primary-600 font-bold px-8 py-4 rounded-2xl hover:bg-primary-50 transition-colors flex-shrink-0 shadow-xl">
                Shop Now →
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* ─── BEST SELLERS ─── */}
      <section className="py-16 bg-cream">
        <div className="container-custom">
          <div className="flex items-center justify-between mb-8">
            <div>
              <h2 className="section-title">🏆 Best Sellers</h2>
              <p className="text-gray-500 mt-1">The snacks Indians can't stop buying</p>
            </div>
            <Link href="/products?isBestSeller=true" className="btn-outline py-2 px-5 text-sm hidden md:flex items-center gap-2">
              View All <FiArrowRight />
            </Link>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6">
            {loading
              ? Array(8).fill(null).map((_, i) => <ProductCardSkeleton key={i} />)
              : bestSellers.map((p) => <ProductCard key={p._id} product={p} />)
            }
          </div>
        </div>
      </section>

      {/* ─── WHY US ─── */}
      <section className="py-16" id="about">
        <div className="container-custom">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <div className="relative rounded-3xl overflow-hidden aspect-video shadow-2xl">
                <Image
                  src="https://images.unsplash.com/photo-1555939594-58d7cb561ad1?w=700"
                  alt="Our Story"
                  fill
                  className="object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
                <div className="absolute bottom-6 left-6 text-white">
                  <div className="font-display text-2xl font-bold">Since 2010</div>
                  <div className="text-white/80">Crafting snacks with love</div>
                </div>
              </div>
            </div>
            <div>
              <div className="inline-block bg-primary-100 text-primary-700 px-4 py-2 rounded-full text-sm font-bold mb-4">
                Our Story
              </div>
              <h2 className="section-title mb-4">Why Namkeen Store?</h2>
              <p className="text-gray-600 text-lg leading-relaxed mb-6">
                We started in a small kitchen in Bikaner, Rajasthan — the snack capital of India. Over the years, we've grown into a beloved brand, but our commitment to authentic recipes and fresh ingredients remains unchanged.
              </p>
              <div className="space-y-4">
                {[
                  { icon: '🌿', title: 'No Artificial Preservatives', desc: 'We use only natural ingredients for a healthier snacking experience' },
                  { icon: '👨‍🍳', title: 'Traditional Recipes', desc: 'Recipes passed down through generations, perfected over decades' },
                  { icon: '📦', title: 'Fresh Daily Batches', desc: 'Made fresh every day and packaged to preserve crunchiness and flavor' },
                  { icon: '🇮🇳', title: 'Made in India', desc: 'Proudly sourcing all ingredients locally and supporting Indian farmers' },
                ].map(({ icon, title, desc }) => (
                  <div key={title} className="flex gap-4 p-4 bg-cream rounded-2xl hover:bg-primary-50 transition-colors">
                    <div className="text-2xl flex-shrink-0">{icon}</div>
                    <div>
                      <div className="font-bold text-gray-800">{title}</div>
                      <div className="text-sm text-gray-500 mt-0.5">{desc}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ─── REVIEWS ─── */}
      <section className="py-16 bg-gradient-to-br from-primary-600 to-primary-800">
        <div className="container-custom">
          <div className="text-center mb-10">
            <h2 className="font-display text-3xl md:text-4xl font-bold text-white">What Our Customers Say</h2>
            <div className="flex items-center justify-center gap-2 mt-3">
              {[1,2,3,4,5].map(i => <FiStar key={i} className="text-amber-400 fill-amber-400" size={20} />)}
              <span className="text-white font-bold ml-2">4.9 / 5</span>
              <span className="text-primary-200 text-sm">(50,000+ reviews)</span>
            </div>
          </div>
          <div className="grid md:grid-cols-3 gap-6">
            {[
              { name: 'Priya Sharma', location: 'Delhi', rating: 5, comment: 'The Bikaneri Bhujia is absolutely divine! It tastes exactly like what my grandmother used to make. Will definitely order again!' },
              { name: 'Rajesh Verma', location: 'Mumbai', rating: 5, comment: 'Fast delivery, excellent packaging and the most authentic namkeen I\'ve had outside Rajasthan. The mixture is outstanding!' },
              { name: 'Sunita Patel', location: 'Ahmedabad', rating: 5, comment: 'Ordered the Makhana for a healthy snack option and it\'s been my go-to since. Great taste, very fresh. Love this store!' },
            ].map(({ name, location, rating, comment }) => (
              <div key={name} className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-2xl p-6 text-white">
                <div className="flex gap-1 mb-3">
                  {Array(rating).fill(null).map((_, i) => <FiStar key={i} size={14} className="text-amber-400 fill-amber-400" />)}
                </div>
                <p className="text-primary-100 leading-relaxed mb-4 italic">"{comment}"</p>
                <div className="flex items-center gap-3 border-t border-white/10 pt-4">
                  <div className="w-10 h-10 bg-primary-400 rounded-full flex items-center justify-center font-bold text-white">
                    {name.charAt(0)}
                  </div>
                  <div>
                    <div className="font-bold text-sm">{name}</div>
                    <div className="text-xs text-primary-200">📍 {location}</div>
                  </div>
                  <div className="ml-auto text-green-400 text-xs font-semibold bg-green-400/20 px-2 py-1 rounded-full">✓ Verified</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ─── CONTACT SECTION ─── */}
      <section className="py-16" id="contact">
        <div className="container-custom">
          <div className="grid lg:grid-cols-2 gap-12">
            <div>
              <h2 className="section-title mb-4">We'd Love to Hear From You</h2>
              <p className="text-gray-500 mb-8">Have a question, feedback, or a bulk order inquiry? Reach out to us anytime!</p>
              <div className="space-y-4">
                {[
                  { icon: '📍', title: 'Visit Us', value: '123 Snack Street, Bikaner, Rajasthan' },
                  { icon: '📞', title: 'Call Us', value: '+91 98765 43210' },
                  { icon: '📧', title: 'Email Us', value: 'hello@namkeenstore.com' },
                  { icon: '🕒', title: 'Business Hours', value: 'Mon–Sat: 9AM–7PM, Sun: 10AM–5PM' },
                ].map(({ icon, title, value }) => (
                  <div key={title} className="flex gap-4 items-start">
                    <div className="w-12 h-12 bg-primary-100 rounded-2xl flex items-center justify-center text-2xl flex-shrink-0">{icon}</div>
                    <div>
                      <div className="font-bold text-gray-800">{title}</div>
                      <div className="text-gray-500">{value}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            <div className="card p-6 md:p-8">
              <h3 className="font-bold text-xl text-gray-800 mb-6">Send Us a Message</h3>
              <form className="space-y-4" onSubmit={(e) => e.preventDefault()}>
                <div className="grid sm:grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm font-semibold text-gray-700 mb-1.5 block">Your Name</label>
                    <input type="text" placeholder="Rajesh Kumar" className="input-field" />
                  </div>
                  <div>
                    <label className="text-sm font-semibold text-gray-700 mb-1.5 block">Email</label>
                    <input type="email" placeholder="you@email.com" className="input-field" />
                  </div>
                </div>
                <div>
                  <label className="text-sm font-semibold text-gray-700 mb-1.5 block">Subject</label>
                  <input type="text" placeholder="Bulk order inquiry" className="input-field" />
                </div>
                <div>
                  <label className="text-sm font-semibold text-gray-700 mb-1.5 block">Message</label>
                  <textarea rows={4} placeholder="Tell us how we can help..." className="input-field resize-none" />
                </div>
                <button type="submit" className="btn-primary w-full">Send Message</button>
              </form>
            </div>
          </div>
        </div>
      </section>

      {/* ─── FAQ ─── */}
      <section className="py-16 bg-cream">
        <div className="container-custom max-w-3xl">
          <div className="text-center mb-10">
            <h2 className="section-title">Frequently Asked Questions</h2>
          </div>
          <div className="space-y-3">
            {[
              { q: 'How fresh are your products?', a: 'All our products are made in fresh batches daily and packed immediately to preserve crunchiness. The manufacturing date is printed on every pack.' },
              { q: 'Do you ship across India?', a: 'Yes! We ship pan-India via trusted courier partners. Orders above ₹499 get free shipping.' },
              { q: 'Are your products suitable for vegetarians?', a: 'Yes, all our products are 100% vegetarian and made without any non-vegetarian ingredients.' },
              { q: 'How long is the shelf life?', a: 'Most products have a shelf life of 3–6 months. We recommend consuming within 2 months of opening for best taste.' },
              { q: 'Can I place a bulk order?', a: 'Absolutely! Contact us at hello@namkeenstore.com or WhatsApp us for custom bulk pricing and corporate gift hampers.' },
            ].map(({ q, a }, i) => (
              <details key={i} className="bg-white rounded-2xl shadow-sm group">
                <summary className="flex items-center justify-between p-5 cursor-pointer font-semibold text-gray-800 list-none">
                  {q}
                  <span className="text-primary-500 group-open:rotate-45 transition-transform duration-200 text-xl font-bold flex-shrink-0 ml-3">+</span>
                </summary>
                <div className="px-5 pb-5 text-gray-600 leading-relaxed">{a}</div>
              </details>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}

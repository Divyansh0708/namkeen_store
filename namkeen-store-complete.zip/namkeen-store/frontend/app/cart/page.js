'use client';
import { useState } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { FiTrash2, FiMinus, FiPlus, FiArrowRight, FiTag, FiX } from 'react-icons/fi';
import { useCart } from '../../context/CartContext';
import { useAuth } from '../../context/AuthContext';

export default function CartPage() {
  const { cart, loading, itemCount, subtotal, discount, shipping, tax, total,
    updateItem, removeItem, applyCoupon, removeCoupon } = useCart();
  const { isLoggedIn } = useAuth();
  const [couponInput, setCouponInput] = useState('');
  const [applyingCoupon, setApplyingCoupon] = useState(false);

  const handleApplyCoupon = async (e) => {
    e.preventDefault();
    if (!couponInput.trim()) return;
    setApplyingCoupon(true);
    await applyCoupon(couponInput.trim().toUpperCase());
    setApplyingCoupon(false);
  };

  if (!isLoggedIn) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-cream">
        <div className="text-center">
          <div className="text-6xl mb-4">🛒</div>
          <h2 className="font-display text-2xl font-bold mb-2">Your Cart Awaits</h2>
          <p className="text-gray-500 mb-6">Please login to view your cart</p>
          <Link href="/auth/login?redirect=/cart" className="btn-primary">Login to Continue</Link>
        </div>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="w-10 h-10 border-4 border-primary-200 border-t-primary-500 rounded-full animate-spin" />
      </div>
    );
  }

  const items = cart?.items || [];

  if (items.length === 0) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-cream">
        <div className="text-center">
          <div className="text-8xl mb-4">🛒</div>
          <h2 className="font-display text-2xl font-bold text-gray-800 mb-2">Your cart is empty</h2>
          <p className="text-gray-500 mb-6">Add some delicious namkeens to your cart!</p>
          <Link href="/products" className="btn-primary">Browse Products</Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="container-custom">
        <h1 className="font-display text-3xl font-bold text-dark mb-8">
          Shopping Cart <span className="text-primary-500 text-2xl">({itemCount} items)</span>
        </h1>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Cart items */}
          <div className="lg:col-span-2 space-y-4">
            {items.map((item) => (
              <div key={item.product?._id} className="card p-4 flex gap-4">
                <Link href={`/products/${item.product?.slug}`} className="relative w-24 h-24 flex-shrink-0 rounded-2xl overflow-hidden bg-gray-50">
                  <Image
                    src={item.product?.images?.[0] || 'https://via.placeholder.com/200'}
                    alt={item.product?.name || 'Product'}
                    fill
                    className="object-cover"
                  />
                </Link>
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-2">
                    <Link href={`/products/${item.product?.slug}`}
                      className="font-bold text-gray-800 hover:text-primary-600 transition-colors line-clamp-2 leading-snug">
                      {item.product?.name}
                    </Link>
                    <button onClick={() => removeItem(item.product?._id)}
                      className="p-1.5 rounded-lg hover:bg-red-50 text-gray-400 hover:text-red-500 transition-colors flex-shrink-0">
                      <FiTrash2 size={16} />
                    </button>
                  </div>
                  <div className="text-sm text-gray-500 mt-0.5">₹{item.price} each</div>
                  <div className="flex items-center justify-between mt-3">
                    <div className="flex items-center border border-gray-200 rounded-xl overflow-hidden">
                      <button
                        onClick={() => item.quantity > 1 ? updateItem(item.product?._id, item.quantity - 1) : removeItem(item.product?._id)}
                        className="w-8 h-8 flex items-center justify-center hover:bg-gray-100 transition-colors">
                        <FiMinus size={12} />
                      </button>
                      <span className="w-10 text-center text-sm font-bold">{item.quantity}</span>
                      <button
                        onClick={() => updateItem(item.product?._id, item.quantity + 1)}
                        disabled={item.quantity >= (item.product?.stock || 10)}
                        className="w-8 h-8 flex items-center justify-center hover:bg-gray-100 transition-colors disabled:opacity-50">
                        <FiPlus size={12} />
                      </button>
                    </div>
                    <span className="font-extrabold text-lg text-gray-900">₹{(item.price * item.quantity).toFixed(2)}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Order summary */}
          <div className="space-y-4">
            {/* Coupon */}
            <div className="card p-5">
              <h3 className="font-bold text-gray-800 mb-3 flex items-center gap-2">
                <FiTag className="text-primary-500" /> Apply Coupon
              </h3>
              {cart?.couponCode ? (
                <div className="flex items-center justify-between bg-green-50 border border-green-200 rounded-xl px-4 py-3">
                  <div>
                    <div className="font-bold text-green-700 text-sm">{cart.couponCode} applied!</div>
                    <div className="text-green-600 text-xs">You save ₹{discount}</div>
                  </div>
                  <button onClick={removeCoupon} className="text-green-600 hover:text-red-500 transition-colors">
                    <FiX size={18} />
                  </button>
                </div>
              ) : (
                <form onSubmit={handleApplyCoupon} className="flex gap-2">
                  <input
                    type="text"
                    value={couponInput}
                    onChange={(e) => setCouponInput(e.target.value.toUpperCase())}
                    placeholder="WELCOME10"
                    className="input-field py-2.5 text-sm flex-1 uppercase"
                  />
                  <button type="submit" disabled={applyingCoupon}
                    className="btn-primary py-2.5 px-4 text-sm flex-shrink-0 disabled:opacity-70">
                    {applyingCoupon ? '...' : 'Apply'}
                  </button>
                </form>
              )}
              <div className="mt-3 flex flex-wrap gap-1.5">
                {['WELCOME10', 'FLAT50', 'DIWALI20'].map((code) => (
                  <button key={code} onClick={() => setCouponInput(code)}
                    className="text-xs px-2 py-1 bg-gray-100 hover:bg-primary-100 hover:text-primary-700 rounded-lg font-mono font-bold transition-colors">
                    {code}
                  </button>
                ))}
              </div>
            </div>

            {/* Price breakdown */}
            <div className="card p-5">
              <h3 className="font-bold text-gray-800 mb-4">Order Summary</h3>
              <div className="space-y-3 text-sm">
                <div className="flex justify-between text-gray-600">
                  <span>Subtotal ({itemCount} items)</span>
                  <span className="font-semibold">₹{subtotal.toFixed(2)}</span>
                </div>
                {discount > 0 && (
                  <div className="flex justify-between text-green-600">
                    <span>Coupon Discount</span>
                    <span className="font-semibold">-₹{discount.toFixed(2)}</span>
                  </div>
                )}
                <div className="flex justify-between text-gray-600">
                  <span>GST (5%)</span>
                  <span className="font-semibold">₹{tax.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-gray-600">
                  <span>Shipping</span>
                  <span className={`font-semibold ${shipping === 0 ? 'text-green-600' : ''}`}>
                    {shipping === 0 ? 'FREE' : `₹${shipping}`}
                  </span>
                </div>
                {shipping > 0 && (
                  <div className="text-xs text-gray-400 bg-orange-50 rounded-lg px-3 py-2">
                    Add ₹{(499 - subtotal).toFixed(0)} more for free delivery
                    <div className="mt-1 h-1.5 bg-orange-100 rounded-full overflow-hidden">
                      <div className="h-full bg-primary-500 rounded-full transition-all" style={{ width: `${Math.min((subtotal / 499) * 100, 100)}%` }} />
                    </div>
                  </div>
                )}
                <div className="flex justify-between font-bold text-lg pt-3 border-t border-gray-100">
                  <span>Total</span>
                  <span className="text-primary-600">₹{total.toFixed(2)}</span>
                </div>
              </div>
              <Link href="/checkout" className="btn-primary w-full text-center mt-5 flex items-center justify-center gap-2 py-3.5">
                Proceed to Checkout <FiArrowRight />
              </Link>
              <Link href="/products" className="block text-center text-sm text-primary-500 font-semibold mt-3 hover:underline">
                ← Continue Shopping
              </Link>
            </div>

            {/* Safety badges */}
            <div className="card p-4">
              <div className="flex flex-wrap gap-3 justify-center text-xs text-gray-500">
                {['🔒 Secure Checkout', '🚚 Fast Delivery', '↩️ Easy Returns'].map((badge) => (
                  <span key={badge} className="font-medium">{badge}</span>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

'use client';
import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { FiCheck, FiPlus } from 'react-icons/fi';
import { useCart } from '../../context/CartContext';
import { useAuth } from '../../context/AuthContext';
import { orderAPI, paymentAPI } from '../../lib/api';
import toast from 'react-hot-toast';

const INDIAN_STATES = ['Andhra Pradesh','Arunachal Pradesh','Assam','Bihar','Chhattisgarh','Goa','Gujarat','Haryana','Himachal Pradesh','Jharkhand','Karnataka','Kerala','Madhya Pradesh','Maharashtra','Manipur','Meghalaya','Mizoram','Nagaland','Odisha','Punjab','Rajasthan','Sikkim','Tamil Nadu','Telangana','Tripura','Uttar Pradesh','Uttarakhand','West Bengal','Delhi','Jammu and Kashmir','Ladakh','Chandigarh','Puducherry'];

export default function CheckoutPage() {
  const router = useRouter();
  const { cart, subtotal, discount, shipping, tax, total, itemCount } = useCart();
  const { user, isLoggedIn } = useAuth();

  const [step, setStep] = useState(1); // 1: address, 2: payment
  const [selectedAddress, setSelectedAddress] = useState(null);
  const [addingAddress, setAddingAddress] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState('razorpay');
  const [placing, setPlacing] = useState(false);

  const [newAddr, setNewAddr] = useState({
    name: user?.name || '', phone: user?.phone || '',
    street: '', city: '', state: '', pincode: '', country: 'India', isDefault: false,
  });

  useEffect(() => {
    if (!isLoggedIn) { router.push('/auth/login?redirect=/checkout'); return; }
    if (!itemCount) { router.push('/cart'); }
  }, [isLoggedIn, itemCount, router]);

  useEffect(() => {
    if (user?.addresses?.length) {
      const def = user.addresses.find(a => a.isDefault) || user.addresses[0];
      setSelectedAddress(def);
    } else {
      setAddingAddress(true);
    }
  }, [user]);

  const loadRazorpay = () => {
    return new Promise((resolve) => {
      if (window.Razorpay) { resolve(true); return; }
      const script = document.createElement('script');
      script.src = 'https://checkout.razorpay.com/v1/checkout.js';
      script.onload = () => resolve(true);
      script.onerror = () => resolve(false);
      document.body.appendChild(script);
    });
  };

  const handlePlaceOrder = async () => {
    if (!selectedAddress) { toast.error('Please select a delivery address'); return; }
    setPlacing(true);
    try {
      const orderData = {
        items: cart.items.map(item => ({
          product: item.product._id,
          quantity: item.quantity,
        })),
        shippingAddress: {
          name: selectedAddress.name,
          phone: selectedAddress.phone,
          street: selectedAddress.street,
          city: selectedAddress.city,
          state: selectedAddress.state,
          pincode: selectedAddress.pincode,
          country: selectedAddress.country || 'India',
        },
        paymentMethod,
        discountAmount: discount,
        couponCode: cart.couponCode,
      };

      if (paymentMethod === 'cod') {
        const { data } = await orderAPI.create(orderData);
        toast.success('Order placed successfully! 🎉');
        router.push(`/orders/${data.order._id}?success=true`);
        return;
      }

      // Razorpay flow
      const loaded = await loadRazorpay();
      if (!loaded) { toast.error('Failed to load payment gateway'); setPlacing(false); return; }

      const rzpRes = await paymentAPI.createRazorpayOrder({ amount: total, currency: 'INR' });
      const rzpOrder = rzpRes.data.order;

      // First create order in our DB
      const { data: orderResult } = await orderAPI.create(orderData);

      const options = {
        key: process.env.NEXT_PUBLIC_RAZORPAY_KEY || rzpRes.data.key,
        amount: rzpOrder.amount,
        currency: rzpOrder.currency,
        name: 'Namkeen Store',
        description: `Order #${orderResult.order.orderNumber}`,
        image: '/logo.png',
        order_id: rzpOrder.id,
        handler: async (response) => {
          try {
            await paymentAPI.verifyRazorpayPayment({
              ...response,
              orderId: orderResult.order._id,
            });
            toast.success('Payment successful! Order confirmed 🎉');
            router.push(`/orders/${orderResult.order._id}?success=true`);
          } catch {
            toast.error('Payment verification failed. Contact support.');
            router.push(`/orders/${orderResult.order._id}`);
          }
        },
        prefill: {
          name: user?.name,
          email: user?.email,
          contact: selectedAddress.phone,
        },
        theme: { color: '#e67e22' },
        modal: {
          ondismiss: () => {
            setPlacing(false);
            toast.error('Payment cancelled');
          }
        }
      };

      const rzp = new window.Razorpay(options);
      rzp.open();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to place order');
      setPlacing(false);
    }
  };

  if (!isLoggedIn || !itemCount) return null;

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="container-custom max-w-5xl">
        <h1 className="font-display text-3xl font-bold text-dark mb-8">Checkout</h1>

        {/* Progress steps */}
        <div className="flex items-center gap-3 mb-8">
          {[{ n: 1, label: 'Delivery Address' }, { n: 2, label: 'Payment' }].map(({ n, label }) => (
            <div key={n} className="flex items-center gap-3">
              <div className={`flex items-center gap-2 ${n <= step ? 'text-primary-600' : 'text-gray-400'}`}>
                <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold ${n < step ? 'bg-primary-500 text-white' : n === step ? 'border-2 border-primary-500 text-primary-600' : 'border-2 border-gray-300'}`}>
                  {n < step ? <FiCheck size={14} /> : n}
                </div>
                <span className="font-semibold text-sm hidden sm:block">{label}</span>
              </div>
              {n < 2 && <div className={`h-0.5 w-12 sm:w-20 ${step > n ? 'bg-primary-500' : 'bg-gray-200'}`} />}
            </div>
          ))}
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Left: steps */}
          <div className="lg:col-span-2 space-y-6">
            {/* Step 1: Address */}
            <div className={`card p-6 ${step !== 1 ? 'opacity-60' : ''}`}>
              <div className="flex items-center justify-between mb-5">
                <h2 className="font-bold text-lg text-gray-800">Delivery Address</h2>
                {step > 1 && (
                  <button onClick={() => setStep(1)} className="text-primary-500 text-sm font-semibold hover:underline">Change</button>
                )}
              </div>
              {step === 1 && (
                <>
                  {/* Saved addresses */}
                  {user?.addresses?.length > 0 && !addingAddress && (
                    <div className="space-y-3 mb-4">
                      {user.addresses.map((addr) => (
                        <div key={addr._id}
                          onClick={() => setSelectedAddress(addr)}
                          className={`p-4 rounded-xl border-2 cursor-pointer transition-all ${selectedAddress?._id === addr._id ? 'border-primary-500 bg-primary-50' : 'border-gray-200 hover:border-primary-300'}`}>
                          <div className="flex items-start gap-3">
                            <div className={`w-5 h-5 rounded-full border-2 flex-shrink-0 mt-0.5 flex items-center justify-center ${selectedAddress?._id === addr._id ? 'border-primary-500 bg-primary-500' : 'border-gray-300'}`}>
                              {selectedAddress?._id === addr._id && <div className="w-2 h-2 bg-white rounded-full" />}
                            </div>
                            <div>
                              <div className="font-bold text-gray-800">{addr.name} <span className="text-gray-400 font-normal text-sm">• {addr.phone}</span></div>
                              <div className="text-sm text-gray-600 mt-0.5">{addr.street}, {addr.city}, {addr.state} — {addr.pincode}</div>
                              {addr.isDefault && <span className="text-xs bg-primary-100 text-primary-700 px-2 py-0.5 rounded-full font-semibold mt-1 inline-block">Default</span>}
                            </div>
                          </div>
                        </div>
                      ))}
                      <button onClick={() => setAddingAddress(true)}
                        className="w-full py-3 border-2 border-dashed border-gray-300 rounded-xl text-gray-500 hover:border-primary-400 hover:text-primary-500 transition-colors flex items-center justify-center gap-2 text-sm font-semibold">
                        <FiPlus size={16} /> Add New Address
                      </button>
                    </div>
                  )}

                  {/* Add address form */}
                  {addingAddress && (
                    <div className="space-y-4 p-4 bg-gray-50 rounded-2xl">
                      <h4 className="font-semibold text-gray-700">New Address</h4>
                      <div className="grid sm:grid-cols-2 gap-4">
                        {[
                          { key: 'name', label: 'Full Name', placeholder: 'Rajesh Kumar' },
                          { key: 'phone', label: 'Phone', placeholder: '9876543210' },
                        ].map(({ key, label, placeholder }) => (
                          <div key={key}>
                            <label className="text-sm font-semibold text-gray-700 mb-1.5 block">{label} *</label>
                            <input value={newAddr[key]} onChange={(e) => setNewAddr(p => ({...p, [key]: e.target.value}))}
                              placeholder={placeholder} className="input-field" required />
                          </div>
                        ))}
                      </div>
                      <div>
                        <label className="text-sm font-semibold text-gray-700 mb-1.5 block">Street Address *</label>
                        <input value={newAddr.street} onChange={(e) => setNewAddr(p => ({...p, street: e.target.value}))}
                          placeholder="House no, Building, Street" className="input-field" required />
                      </div>
                      <div className="grid sm:grid-cols-3 gap-4">
                        {[
                          { key: 'city', label: 'City', placeholder: 'Bikaner' },
                          { key: 'pincode', label: 'Pincode', placeholder: '334001' },
                        ].map(({ key, label, placeholder }) => (
                          <div key={key}>
                            <label className="text-sm font-semibold text-gray-700 mb-1.5 block">{label} *</label>
                            <input value={newAddr[key]} onChange={(e) => setNewAddr(p => ({...p, [key]: e.target.value}))}
                              placeholder={placeholder} className="input-field" required />
                          </div>
                        ))}
                        <div>
                          <label className="text-sm font-semibold text-gray-700 mb-1.5 block">State *</label>
                          <select value={newAddr.state} onChange={(e) => setNewAddr(p => ({...p, state: e.target.value}))} className="input-field" required>
                            <option value="">Select State</option>
                            {INDIAN_STATES.map(s => <option key={s} value={s}>{s}</option>)}
                          </select>
                        </div>
                      </div>
                      <div className="flex gap-3">
                        <button onClick={() => { setSelectedAddress(newAddr); setAddingAddress(false); }}
                          className="btn-primary py-2.5 flex-1">Use This Address</button>
                        {user?.addresses?.length > 0 && (
                          <button onClick={() => setAddingAddress(false)} className="btn-secondary py-2.5 px-4">Cancel</button>
                        )}
                      </div>
                    </div>
                  )}

                  {selectedAddress && !addingAddress && (
                    <button onClick={() => setStep(2)} className="btn-primary w-full py-3.5 mt-2">
                      Deliver to This Address →
                    </button>
                  )}
                </>
              )}

              {step > 1 && selectedAddress && (
                <div className="text-sm text-gray-600">
                  <span className="font-semibold">{selectedAddress.name}</span> • {selectedAddress.phone}<br />
                  {selectedAddress.street}, {selectedAddress.city}, {selectedAddress.state} — {selectedAddress.pincode}
                </div>
              )}
            </div>

            {/* Step 2: Payment */}
            {step >= 2 && (
              <div className="card p-6">
                <h2 className="font-bold text-lg text-gray-800 mb-5">Payment Method</h2>
                <div className="space-y-3">
                  {[
                    { id: 'razorpay', icon: '💳', title: 'Online Payment', sub: 'UPI, Cards, Net Banking, Wallets' },
                    { id: 'cod', icon: '💵', title: 'Cash on Delivery', sub: 'Pay when your order arrives' },
                  ].map(({ id, icon, title, sub }) => (
                    <div key={id}
                      onClick={() => setPaymentMethod(id)}
                      className={`p-4 rounded-xl border-2 cursor-pointer transition-all flex items-center gap-4 ${paymentMethod === id ? 'border-primary-500 bg-primary-50' : 'border-gray-200 hover:border-primary-300'}`}>
                      <div className={`w-5 h-5 rounded-full border-2 flex-shrink-0 flex items-center justify-center ${paymentMethod === id ? 'border-primary-500 bg-primary-500' : 'border-gray-300'}`}>
                        {paymentMethod === id && <div className="w-2 h-2 bg-white rounded-full" />}
                      </div>
                      <span className="text-2xl">{icon}</span>
                      <div>
                        <div className="font-bold text-gray-800">{title}</div>
                        <div className="text-xs text-gray-500">{sub}</div>
                      </div>
                      {id === 'razorpay' && (
                        <span className="ml-auto text-xs bg-green-100 text-green-700 px-2 py-1 rounded-full font-semibold">Recommended</span>
                      )}
                    </div>
                  ))}
                </div>
                <button
                  onClick={handlePlaceOrder}
                  disabled={placing}
                  className="btn-primary w-full py-4 mt-5 text-base font-bold disabled:opacity-70 flex items-center justify-center gap-3">
                  {placing ? (
                    <>
                      <span className="w-5 h-5 border-2 border-white/50 border-t-white rounded-full animate-spin" />
                      Processing...
                    </>
                  ) : (
                    <>🎉 Place Order — ₹{total.toFixed(2)}</>
                  )}
                </button>
                <p className="text-center text-xs text-gray-400 mt-3">
                  🔒 Your payment is secured by 256-bit SSL encryption
                </p>
              </div>
            )}
          </div>

          {/* Order summary sidebar */}
          <div className="card p-5 h-fit">
            <h3 className="font-bold text-gray-800 mb-4">Order Summary</h3>
            <div className="space-y-3 mb-4 max-h-64 overflow-y-auto">
              {cart?.items?.map((item) => (
                <div key={item.product?._id} className="flex gap-3 text-sm">
                  <div className="relative w-12 h-12 flex-shrink-0 rounded-xl overflow-hidden bg-gray-50">
                    <img src={item.product?.images?.[0] || '/placeholder.jpg'} alt="" className="w-full h-full object-cover" />
                    <span className="absolute -top-1 -right-1 w-5 h-5 bg-primary-500 text-white text-xs rounded-full flex items-center justify-center font-bold">{item.quantity}</span>
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="font-medium text-gray-700 line-clamp-1">{item.product?.name}</div>
                    <div className="text-gray-500">₹{item.price} × {item.quantity}</div>
                  </div>
                  <div className="font-bold text-gray-800 flex-shrink-0">₹{(item.price * item.quantity).toFixed(0)}</div>
                </div>
              ))}
            </div>
            <div className="border-t border-gray-100 pt-4 space-y-2 text-sm">
              <div className="flex justify-between text-gray-600"><span>Subtotal</span><span>₹{subtotal.toFixed(2)}</span></div>
              {discount > 0 && <div className="flex justify-between text-green-600"><span>Discount</span><span>-₹{discount}</span></div>}
              <div className="flex justify-between text-gray-600"><span>GST</span><span>₹{tax.toFixed(2)}</span></div>
              <div className="flex justify-between text-gray-600"><span>Shipping</span><span className={shipping === 0 ? 'text-green-600 font-semibold' : ''}>{shipping === 0 ? 'FREE' : `₹${shipping}`}</span></div>
              <div className="flex justify-between font-bold text-lg pt-2 border-t border-gray-100">
                <span>Total</span><span className="text-primary-600">₹{total.toFixed(2)}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

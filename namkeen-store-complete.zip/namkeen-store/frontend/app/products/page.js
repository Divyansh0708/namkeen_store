'use client';
import { useState, useEffect, useCallback } from 'react';
import { useSearchParams, useRouter } from 'next/navigation';
import { FiFilter, FiX, FiChevronDown, FiGrid, FiList, FiSearch } from 'react-icons/fi';
import ProductCard from '../../components/product/ProductCard';
import { ProductGridSkeleton } from '../../components/common/Skeletons';
import { productAPI, categoryAPI } from '../../lib/api';

export default function ProductsPage() {
  const searchParams = useSearchParams();
  const router = useRouter();

  const [products, setProducts] = useState([]);
  const [categories, setCategories] = useState([]);
  const [pagination, setPagination] = useState({});
  const [loading, setLoading] = useState(true);
  const [filtersOpen, setFiltersOpen] = useState(false);

  const keyword = searchParams.get('keyword') || '';
  const categoryId = searchParams.get('category') || '';
  const minPrice = searchParams.get('minPrice') || '';
  const maxPrice = searchParams.get('maxPrice') || '';
  const sort = searchParams.get('sort') || '-createdAt';
  const page = parseInt(searchParams.get('page') || '1');
  const isFeatured = searchParams.get('isFeatured') || '';
  const isBestSeller = searchParams.get('isBestSeller') || '';
  const isNew = searchParams.get('isNew') || '';

  const [localMin, setLocalMin] = useState(minPrice);
  const [localMax, setLocalMax] = useState(maxPrice);

  const fetchProducts = useCallback(async () => {
    setLoading(true);
    try {
      const params = { page, limit: 12, sort };
      if (keyword) params.keyword = keyword;
      if (categoryId) params.category = categoryId;
      if (minPrice) params.minPrice = minPrice;
      if (maxPrice) params.maxPrice = maxPrice;
      if (isFeatured) params.isFeatured = isFeatured;
      if (isBestSeller) params.isBestSeller = isBestSeller;
      if (isNew) params.isNew = isNew;

      const { data } = await productAPI.getAll(params);
      setProducts(data.products);
      setPagination(data.pagination);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  }, [keyword, categoryId, minPrice, maxPrice, sort, page, isFeatured, isBestSeller, isNew]);

  useEffect(() => {
    fetchProducts();
  }, [fetchProducts]);

  useEffect(() => {
    categoryAPI.getAll().then(({ data }) => setCategories(data.categories)).catch(() => {});
  }, []);

  const updateParam = (key, value) => {
    const params = new URLSearchParams(searchParams.toString());
    if (value) params.set(key, value); else params.delete(key);
    params.delete('page');
    router.push(`/products?${params.toString()}`);
  };

  const clearAllFilters = () => router.push('/products');

  const applyPriceFilter = () => {
    const params = new URLSearchParams(searchParams.toString());
    if (localMin) params.set('minPrice', localMin); else params.delete('minPrice');
    if (localMax) params.set('maxPrice', localMax); else params.delete('maxPrice');
    params.delete('page');
    router.push(`/products?${params.toString()}`);
  };

  const hasActiveFilters = keyword || categoryId || minPrice || maxPrice || isFeatured || isBestSeller || isNew;

  const pageTitle = keyword ? `Search: "${keyword}"` :
    isBestSeller ? 'Best Sellers' :
    isFeatured ? 'Featured Products' :
    isNew ? 'New Arrivals' :
    categories.find(c => c._id === categoryId)?.name || 'All Products';

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Page header */}
      <div className="bg-white border-b border-gray-100 py-6">
        <div className="container-custom">
          <div className="flex items-center justify-between flex-wrap gap-4">
            <div>
              <h1 className="font-display text-2xl md:text-3xl font-bold text-dark">{pageTitle}</h1>
              {!loading && (
                <p className="text-gray-500 text-sm mt-1">{pagination.total || 0} products found</p>
              )}
            </div>
            <div className="flex items-center gap-3">
              {/* Sort */}
              <div className="relative">
                <select
                  value={sort}
                  onChange={(e) => updateParam('sort', e.target.value)}
                  className="appearance-none input-field py-2 pl-4 pr-10 text-sm cursor-pointer"
                >
                  <option value="-createdAt">Newest First</option>
                  <option value="price">Price: Low to High</option>
                  <option value="-price">Price: High to Low</option>
                  <option value="-ratings">Top Rated</option>
                  <option value="-numReviews">Most Reviewed</option>
                </select>
                <FiChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none" size={14} />
              </div>
              {/* Mobile filter toggle */}
              <button
                onClick={() => setFiltersOpen(true)}
                className="flex items-center gap-2 btn-secondary py-2 px-4 text-sm lg:hidden"
              >
                <FiFilter size={15} /> Filters
                {hasActiveFilters && <span className="w-2 h-2 bg-primary-500 rounded-full" />}
              </button>
            </div>
          </div>
          {/* Active filter chips */}
          {hasActiveFilters && (
            <div className="flex flex-wrap gap-2 mt-4">
              {keyword && <FilterChip label={`Search: "${keyword}"`} onRemove={() => updateParam('keyword', '')} />}
              {categoryId && <FilterChip label={categories.find(c => c._id === categoryId)?.name || 'Category'} onRemove={() => updateParam('category', '')} />}
              {minPrice && <FilterChip label={`Min ₹${minPrice}`} onRemove={() => updateParam('minPrice', '')} />}
              {maxPrice && <FilterChip label={`Max ₹${maxPrice}`} onRemove={() => updateParam('maxPrice', '')} />}
              {isBestSeller && <FilterChip label="Best Sellers" onRemove={() => updateParam('isBestSeller', '')} />}
              {isFeatured && <FilterChip label="Featured" onRemove={() => updateParam('isFeatured', '')} />}
              {isNew && <FilterChip label="New Arrivals" onRemove={() => updateParam('isNew', '')} />}
              <button onClick={clearAllFilters} className="text-xs text-red-500 font-semibold hover:underline px-2 py-1">
                Clear All
              </button>
            </div>
          )}
        </div>
      </div>

      <div className="container-custom py-8">
        <div className="flex gap-8">
          {/* Sidebar Filters — desktop */}
          <aside className="hidden lg:block w-64 flex-shrink-0">
            <FilterSidebar
              categories={categories}
              categoryId={categoryId}
              localMin={localMin}
              localMax={localMax}
              setLocalMin={setLocalMin}
              setLocalMax={setLocalMax}
              onCategoryChange={(id) => updateParam('category', id)}
              onApplyPrice={applyPriceFilter}
              onToggle={(key, val) => updateParam(key, val)}
              isBestSeller={isBestSeller}
              isFeatured={isFeatured}
              isNew={isNew}
            />
          </aside>

          {/* Products grid */}
          <div className="flex-1 min-w-0">
            {loading ? (
              <ProductGridSkeleton count={12} />
            ) : products.length === 0 ? (
              <div className="text-center py-24">
                <div className="text-6xl mb-4">🔍</div>
                <h3 className="font-bold text-xl text-gray-700 mb-2">No products found</h3>
                <p className="text-gray-500 mb-6">Try adjusting your filters or search term</p>
                <button onClick={clearAllFilters} className="btn-primary">Browse All Products</button>
              </div>
            ) : (
              <>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4 md:gap-5">
                  {products.map((p) => <ProductCard key={p._id} product={p} />)}
                </div>
                {/* Pagination */}
                {pagination.pages > 1 && (
                  <div className="flex items-center justify-center gap-2 mt-10">
                    {Array.from({ length: pagination.pages }, (_, i) => i + 1).map((p) => (
                      <button
                        key={p}
                        onClick={() => updateParam('page', p.toString())}
                        className={`w-10 h-10 rounded-xl font-bold text-sm transition-all ${
                          p === page
                            ? 'bg-primary-500 text-white shadow-orange'
                            : 'bg-white text-gray-600 hover:bg-primary-50 hover:text-primary-600 border border-gray-200'
                        }`}
                      >
                        {p}
                      </button>
                    ))}
                  </div>
                )}
              </>
            )}
          </div>
        </div>
      </div>

      {/* Mobile filter drawer */}
      {filtersOpen && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div className="absolute inset-0 bg-black/50" onClick={() => setFiltersOpen(false)} />
          <div className="absolute right-0 top-0 bottom-0 w-80 bg-white shadow-2xl overflow-y-auto">
            <div className="flex items-center justify-between p-5 border-b border-gray-100">
              <h3 className="font-bold text-lg">Filters</h3>
              <button onClick={() => setFiltersOpen(false)} className="p-2 rounded-xl hover:bg-gray-100">
                <FiX size={20} />
              </button>
            </div>
            <div className="p-5">
              <FilterSidebar
                categories={categories}
                categoryId={categoryId}
                localMin={localMin}
                localMax={localMax}
                setLocalMin={setLocalMin}
                setLocalMax={setLocalMax}
                onCategoryChange={(id) => { updateParam('category', id); setFiltersOpen(false); }}
                onApplyPrice={() => { applyPriceFilter(); setFiltersOpen(false); }}
                onToggle={(key, val) => { updateParam(key, val); setFiltersOpen(false); }}
                isBestSeller={isBestSeller}
                isFeatured={isFeatured}
                isNew={isNew}
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function FilterChip({ label, onRemove }) {
  return (
    <span className="flex items-center gap-1.5 bg-primary-100 text-primary-700 px-3 py-1 rounded-full text-xs font-semibold">
      {label}
      <button onClick={onRemove} className="hover:text-primary-900">
        <FiX size={12} />
      </button>
    </span>
  );
}

function FilterSidebar({ categories, categoryId, localMin, localMax, setLocalMin, setLocalMax, onCategoryChange, onApplyPrice, onToggle, isBestSeller, isFeatured, isNew }) {
  return (
    <div className="space-y-6">
      {/* Quick Filters */}
      <div>
        <h4 className="font-bold text-gray-800 mb-3">Quick Filters</h4>
        <div className="space-y-2">
          {[
            { key: 'isBestSeller', val: 'true', label: '⭐ Best Sellers', active: isBestSeller },
            { key: 'isFeatured', val: 'true', label: '🔥 Featured', active: isFeatured },
            { key: 'isNew', val: 'true', label: '✨ New Arrivals', active: isNew },
          ].map(({ key, val, label, active }) => (
            <button key={key}
              onClick={() => onToggle(key, active ? '' : val)}
              className={`w-full text-left px-4 py-2.5 rounded-xl text-sm font-semibold transition-colors ${active ? 'bg-primary-500 text-white' : 'bg-gray-50 text-gray-700 hover:bg-primary-50 hover:text-primary-600'}`}>
              {label}
            </button>
          ))}
        </div>
      </div>

      {/* Categories */}
      <div>
        <h4 className="font-bold text-gray-800 mb-3">Categories</h4>
        <div className="space-y-1">
          <button
            onClick={() => onCategoryChange('')}
            className={`w-full text-left px-3 py-2 rounded-xl text-sm font-medium transition-colors ${!categoryId ? 'bg-primary-500 text-white' : 'text-gray-600 hover:bg-gray-50'}`}>
            All Categories
          </button>
          {categories.map((cat) => (
            <button
              key={cat._id}
              onClick={() => onCategoryChange(cat._id === categoryId ? '' : cat._id)}
              className={`w-full text-left px-3 py-2 rounded-xl text-sm font-medium transition-colors flex items-center gap-2 ${cat._id === categoryId ? 'bg-primary-500 text-white' : 'text-gray-600 hover:bg-gray-50'}`}>
              <span>{cat.icon}</span> {cat.name}
            </button>
          ))}
        </div>
      </div>

      {/* Price Range */}
      <div>
        <h4 className="font-bold text-gray-800 mb-3">Price Range</h4>
        <div className="space-y-3">
          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="text-xs text-gray-500 mb-1 block">Min ₹</label>
              <input type="number" placeholder="0" value={localMin}
                onChange={(e) => setLocalMin(e.target.value)}
                className="input-field py-2 text-sm" min="0" />
            </div>
            <div>
              <label className="text-xs text-gray-500 mb-1 block">Max ₹</label>
              <input type="number" placeholder="1000" value={localMax}
                onChange={(e) => setLocalMax(e.target.value)}
                className="input-field py-2 text-sm" min="0" />
            </div>
          </div>
          <div className="flex flex-wrap gap-2">
            {[['0','99'], ['100','199'], ['200','499'], ['500','']].map(([min, max]) => (
              <button key={`${min}-${max}`}
                onClick={() => { setLocalMin(min); setLocalMax(max); }}
                className="text-xs px-3 py-1.5 bg-gray-100 hover:bg-primary-100 hover:text-primary-700 rounded-lg font-medium transition-colors">
                {max ? `₹${min}–₹${max}` : `₹${min}+`}
              </button>
            ))}
          </div>
          <button onClick={onApplyPrice} className="btn-primary w-full py-2 text-sm">Apply Price Filter</button>
        </div>
      </div>
    </div>
  );
}

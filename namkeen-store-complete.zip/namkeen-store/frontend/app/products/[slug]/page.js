'use client';
import { useState, useEffect } from 'react';
import { useParams, useRouter } from 'next/navigation';
import Image from 'next/image';
import Link from 'next/link';
import {
  FiShoppingCart, FiHeart, FiShare2, FiMinus, FiPlus,
  FiChevronRight, FiTruck, FiShield, FiRefreshCw, FiStar
} from 'react-icons/fi';
import { productAPI, reviewAPI, wishlistAPI } from '../../../lib/api';
import { useCart } from '../../../context/CartContext';
import { useAuth } from '../../../context/AuthContext';
import ProductCard from '../../../components/product/ProductCard';
import StarRating from '../../../components/common/StarRating';
import toast from 'react-hot-toast';

export default function ProductDetailPage() {
  const { slug } = useParams();
  const router = useRouter();
  const { addToCart } = useCart();
  const { isLoggedIn, user } = useAuth();

  const [product, setProduct] = useState(null);
  const [related, setRelated] = useState([]);
  const [reviews, setReviews] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedImage, setSelectedImage] = useState(0);
  const [quantity, setQuantity] = useState(1);
  const [inWishlist, setInWishlist] = useState(false);
  const [activeTab, setActiveTab] = useState('description');
  const [addingToCart, setAddingToCart] = useState(false);
  const [reviewForm, setReviewForm] = useState({ rating: 5, title: '', comment: '' });
  const [submittingReview, setSubmittingReview] = useState(false);

  useEffect(() => {
    const fetchProduct = async () => {
      setLoading(true);
      try {
        const { data } = await productAPI.getOne(slug);
        setProduct(data.product);
        setRelated(data.related);
        // Fetch reviews
        const revRes = await reviewAPI.getProductReviews(data.product._id);
        setReviews(revRes.data.reviews);
      } catch {
        router.push('/products');
      } finally {
        setLoading(false);
      }
    };
    fetchProduct();
  }, [slug, router]);

  if (loading) return <ProductDetailSkeleton />;
  if (!product) return null;

  const effectivePrice = product.offerPrice || product.price;
  const discount = product.offerPrice
    ? Math.round(((product.price - product.offerPrice) / product.price) * 100)
    : 0;

  const handleAddToCart = async () => {
    setAddingToCart(true);
    await addToCart(product._id, quantity);
    setAddingToCart(false);
  };

  const handleBuyNow = async () => {
    await handleAddToCart();
    router.push('/cart');
  };

  const handleWishlist = async () => {
    if (!isLoggedIn) { toast.error('Please login first'); return; }
    try {
      const { data } = await wishlistAPI.toggle(product._id);
      setInWishlist(data.inWishlist);
      toast.success(data.action === 'added' ? 'Added to wishlist ❤️' : 'Removed from wishlist');
    } catch { toast.error('Failed'); }
  };

  const handleReviewSubmit = async (e) => {
    e.preventDefault();
    if (!isLoggedIn) { toast.error('Please login to leave a review'); return; }
    setSubmittingReview(true);
    try {
      const { data } = await reviewAPI.create({ productId: product._id, ...reviewForm });
      setReviews((prev) => [data.review, ...prev]);
      setReviewForm({ rating: 5, title: '', comment: '' });
      toast.success('Review submitted! ⭐');
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to submit review');
    } finally {
      setSubmittingReview(false);
    }
  };

  return (
    <div className="min-h-screen">
      {/* Breadcrumb */}
      <div className="bg-cream py-3 border-b border-orange-100">
        <div className="container-custom">
          <div className="flex items-center gap-2 text-sm text-gray-500">
            <Link href="/" className="hover:text-primary-500">Home</Link>
            <FiChevronRight size={12} />
            <Link href="/products" className="hover:text-primary-500">Products</Link>
            <FiChevronRight size={12} />
            {product.category && (
              <>
                <Link href={`/products?category=${product.category._id}`} className="hover:text-primary-500">
                  {product.category.name}
                </Link>
                <FiChevronRight size={12} />
              </>
            )}
            <span className="text-gray-800 font-medium truncate max-w-48">{product.name}</span>
          </div>
        </div>
      </div>

      {/* Product Main */}
      <section className="container-custom py-10">
        <div className="grid lg:grid-cols-2 gap-10 xl:gap-16">
          {/* Images */}
          <div className="space-y-4">
            <div className="relative aspect-square rounded-3xl overflow-hidden bg-gray-50 shadow-md">
              <Image
                src={product.images?.[selectedImage] || 'https://via.placeholder.com/600x600?text=Namkeen'}
                alt={product.name}
                fill
                className="object-cover"
                sizes="(max-width: 768px) 100vw, 50vw"
                priority
              />
              {discount > 0 && (
                <div className="absolute top-4 left-4 bg-red-500 text-white font-bold text-sm px-3 py-1.5 rounded-xl shadow">
                  {discount}% OFF
                </div>
              )}
            </div>
            {product.images?.length > 1 && (
              <div className="flex gap-3 overflow-x-auto pb-1">
                {product.images.map((img, i) => (
                  <button
                    key={i}
                    onClick={() => setSelectedImage(i)}
                    className={`relative w-20 h-20 flex-shrink-0 rounded-xl overflow-hidden border-2 transition-all ${
                      selectedImage === i ? 'border-primary-500 shadow-orange' : 'border-gray-200 hover:border-primary-300'
                    }`}
                  >
                    <Image src={img} alt="" fill className="object-cover" />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Info */}
          <div className="space-y-5">
            {/* Category & badges */}
            <div className="flex flex-wrap gap-2">
              {product.category && (
                <Link href={`/products?category=${product.category._id}`}
                  className="badge bg-primary-100 text-primary-700 hover:bg-primary-200 transition-colors">
                  {product.category.icon} {product.category.name}
                </Link>
              )}
              {product.isBestSeller && <span className="badge bg-amber-100 text-amber-700">⭐ Best Seller</span>}
              {product.isNew && <span className="badge bg-green-100 text-green-700">✨ New</span>}
              {product.stock === 0 && <span className="badge bg-red-100 text-red-600">Out of Stock</span>}
              {product.stock > 0 && product.stock <= 10 && (
                <span className="badge bg-orange-100 text-orange-700">Only {product.stock} left!</span>
              )}
            </div>

            <h1 className="font-display text-3xl md:text-4xl font-bold text-dark leading-tight">{product.name}</h1>

            {/* Rating */}
            {product.numReviews > 0 && (
              <div className="flex items-center gap-3">
                <StarRating rating={product.ratings} showValue />
                <span className="text-gray-500 text-sm">({product.numReviews} reviews)</span>
                <button onClick={() => setActiveTab('reviews')} className="text-primary-500 text-sm font-semibold hover:underline">
                  Read reviews
                </button>
              </div>
            )}

            {product.shortDescription && (
              <p className="text-gray-600 text-lg leading-relaxed">{product.shortDescription}</p>
            )}

            {/* Price */}
            <div className="flex items-baseline gap-3 py-4 border-y border-gray-100">
              <span className="font-display text-4xl font-bold text-primary-600">₹{effectivePrice}</span>
              {discount > 0 && (
                <>
                  <span className="text-xl text-gray-400 line-through">₹{product.price}</span>
                  <span className="badge bg-red-100 text-red-600 text-sm">Save ₹{product.price - effectivePrice}</span>
                </>
              )}
            </div>

            {/* Meta */}
            <div className="grid grid-cols-2 gap-3 text-sm">
              {product.weight && (
                <div className="flex items-center gap-2 bg-gray-50 rounded-xl p-3">
                  <span className="text-lg">⚖️</span>
                  <div><div className="text-gray-400 text-xs">Weight</div><div className="font-semibold">{product.weight}</div></div>
                </div>
              )}
              {product.shelfLife && (
                <div className="flex items-center gap-2 bg-gray-50 rounded-xl p-3">
                  <span className="text-lg">📅</span>
                  <div><div className="text-gray-400 text-xs">Shelf Life</div><div className="font-semibold">{product.shelfLife}</div></div>
                </div>
              )}
              {product.brand && (
                <div className="flex items-center gap-2 bg-gray-50 rounded-xl p-3">
                  <span className="text-lg">🏷️</span>
                  <div><div className="text-gray-400 text-xs">Brand</div><div className="font-semibold">{product.brand}</div></div>
                </div>
              )}
              {product.countryOfOrigin && (
                <div className="flex items-center gap-2 bg-gray-50 rounded-xl p-3">
                  <span className="text-lg">🇮🇳</span>
                  <div><div className="text-gray-400 text-xs">Origin</div><div className="font-semibold">{product.countryOfOrigin}</div></div>
                </div>
              )}
            </div>

            {/* Quantity + Actions */}
            <div className="space-y-3">
              <div className="flex items-center gap-4">
                <span className="font-semibold text-gray-700">Quantity:</span>
                <div className="flex items-center border border-gray-200 rounded-xl overflow-hidden">
                  <button
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    className="w-10 h-10 flex items-center justify-center hover:bg-gray-100 transition-colors"
                  >
                    <FiMinus size={14} />
                  </button>
                  <span className="w-12 text-center font-bold">{quantity}</span>
                  <button
                    onClick={() => setQuantity(Math.min(product.stock, 10, quantity + 1))}
                    className="w-10 h-10 flex items-center justify-center hover:bg-gray-100 transition-colors"
                  >
                    <FiPlus size={14} />
                  </button>
                </div>
                <span className="text-sm text-gray-400">{product.stock} available</span>
              </div>

              <div className="flex gap-3">
                <button
                  onClick={handleAddToCart}
                  disabled={product.stock === 0 || addingToCart}
                  className="flex-1 btn-outline flex items-center justify-center gap-2 py-3.5 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {addingToCart ? <span className="w-5 h-5 border-2 border-primary-500/50 border-t-primary-500 rounded-full animate-spin" /> : <FiShoppingCart />}
                  Add to Cart
                </button>
                <button
                  onClick={handleBuyNow}
                  disabled={product.stock === 0}
                  className="flex-1 btn-primary flex items-center justify-center gap-2 py-3.5 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  Buy Now
                </button>
              </div>

              <div className="flex gap-2">
                <button onClick={handleWishlist}
                  className={`flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl border transition-colors text-sm font-semibold ${inWishlist ? 'bg-red-50 border-red-200 text-red-500' : 'border-gray-200 text-gray-600 hover:bg-gray-50'}`}>
                  <FiHeart size={16} fill={inWishlist ? 'currentColor' : 'none'} />
                  {inWishlist ? 'Wishlisted' : 'Add to Wishlist'}
                </button>
                <button onClick={() => { navigator.share?.({ title: product.name, url: window.location.href }) || navigator.clipboard?.writeText(window.location.href); toast.success('Link copied!'); }}
                  className="px-4 py-2.5 rounded-xl border border-gray-200 text-gray-600 hover:bg-gray-50 transition-colors">
                  <FiShare2 size={16} />
                </button>
              </div>
            </div>

            {/* Delivery info */}
            <div className="grid sm:grid-cols-3 gap-3 pt-2">
              {[
                { icon: FiTruck, title: 'Free Delivery', sub: 'On orders ₹499+' },
                { icon: FiShield, title: 'Secure Payment', sub: 'Razorpay protected' },
                { icon: FiRefreshCw, title: 'Easy Returns', sub: '7-day policy' },
              ].map(({ icon: Icon, title, sub }) => (
                <div key={title} className="flex gap-2 items-start bg-cream rounded-xl p-3">
                  <Icon size={16} className="text-primary-500 mt-0.5 flex-shrink-0" />
                  <div>
                    <div className="font-semibold text-xs text-gray-800">{title}</div>
                    <div className="text-xs text-gray-500">{sub}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Tabs: description, ingredients, reviews */}
      <section className="container-custom pb-12">
        <div className="flex gap-1 border-b border-gray-200 mb-6 overflow-x-auto">
          {['description', 'ingredients', 'nutrition', 'reviews'].map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-5 py-3 font-semibold text-sm capitalize whitespace-nowrap transition-colors border-b-2 -mb-px ${
                activeTab === tab
                  ? 'border-primary-500 text-primary-600'
                  : 'border-transparent text-gray-500 hover:text-gray-800'
              }`}
            >
              {tab}
              {tab === 'reviews' && ` (${reviews.length})`}
            </button>
          ))}
        </div>

        <div className="max-w-3xl">
          {activeTab === 'description' && (
            <div className="prose prose-gray max-w-none">
              <p className="text-gray-600 leading-relaxed text-lg">{product.description}</p>
              {product.storage && (
                <div className="mt-6 p-4 bg-blue-50 rounded-2xl flex gap-3">
                  <span className="text-2xl">📦</span>
                  <div>
                    <div className="font-bold text-blue-800">Storage Instructions</div>
                    <div className="text-blue-700 text-sm mt-1">{product.storage}</div>
                  </div>
                </div>
              )}
            </div>
          )}

          {activeTab === 'ingredients' && (
            <div>
              <p className="text-gray-600 leading-relaxed">{product.ingredients || 'Ingredients information not available.'}</p>
              <div className="mt-6 p-4 bg-green-50 rounded-2xl flex gap-3">
                <span className="text-2xl">✅</span>
                <div>
                  <div className="font-bold text-green-800">100% Vegetarian</div>
                  <div className="text-green-700 text-sm mt-1">All our products are vegetarian and made without any animal-derived ingredients.</div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'nutrition' && product.nutritionInfo && (
            <div>
              <p className="text-sm text-gray-500 mb-4">Approximate values per 100g serving</p>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                {Object.entries(product.nutritionInfo).filter(([, v]) => v).map(([key, value]) => (
                  <div key={key} className="bg-gray-50 rounded-2xl p-4 text-center">
                    <div className="text-2xl font-bold text-primary-600">{value}</div>
                    <div className="text-sm text-gray-500 capitalize mt-1">{key}</div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'reviews' && (
            <div className="space-y-6">
              {/* Rating summary */}
              {reviews.length > 0 && (
                <div className="flex items-center gap-6 p-5 bg-cream rounded-2xl">
                  <div className="text-center">
                    <div className="text-5xl font-bold text-primary-600">{product.ratings.toFixed(1)}</div>
                    <StarRating rating={product.ratings} size={14} />
                    <div className="text-xs text-gray-500 mt-1">{product.numReviews} reviews</div>
                  </div>
                </div>
              )}

              {/* Write review */}
              {isLoggedIn && (
                <form onSubmit={handleReviewSubmit} className="card p-5 space-y-4">
                  <h4 className="font-bold text-gray-800">Write a Review</h4>
                  <div>
                    <label className="text-sm font-semibold text-gray-600 mb-2 block">Your Rating</label>
                    <div className="flex gap-1">
                      {[1,2,3,4,5].map((star) => (
                        <button key={star} type="button" onClick={() => setReviewForm(p => ({...p, rating: star}))}>
                          <FiStar size={24} className={star <= reviewForm.rating ? 'text-amber-400 fill-amber-400' : 'text-gray-300 fill-gray-300'} />
                        </button>
                      ))}
                    </div>
                  </div>
                  <input
                    type="text"
                    placeholder="Review title (optional)"
                    value={reviewForm.title}
                    onChange={(e) => setReviewForm(p => ({...p, title: e.target.value}))}
                    className="input-field"
                  />
                  <textarea
                    placeholder="Share your experience with this product..."
                    value={reviewForm.comment}
                    onChange={(e) => setReviewForm(p => ({...p, comment: e.target.value}))}
                    className="input-field resize-none"
                    rows={3}
                    required
                  />
                  <button type="submit" disabled={submittingReview} className="btn-primary py-2.5 disabled:opacity-70">
                    {submittingReview ? 'Submitting...' : 'Submit Review'}
                  </button>
                </form>
              )}

              {/* Reviews list */}
              {reviews.length === 0 ? (
                <div className="text-center py-8 text-gray-400">
                  <div className="text-4xl mb-2">⭐</div>
                  <p>No reviews yet. Be the first to review!</p>
                </div>
              ) : (
                reviews.map((rev) => (
                  <div key={rev._id} className="border-b border-gray-100 pb-5">
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex items-center gap-3">
                        <div className="w-9 h-9 rounded-full bg-primary-100 flex items-center justify-center font-bold text-primary-600">
                          {rev.user?.name?.charAt(0).toUpperCase()}
                        </div>
                        <div>
                          <div className="font-semibold text-sm">{rev.user?.name}</div>
                          <StarRating rating={rev.rating} size={12} />
                        </div>
                      </div>
                      <span className="text-xs text-gray-400">
                        {new Date(rev.createdAt).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}
                      </span>
                    </div>
                    {rev.title && <p className="font-semibold text-gray-800 mt-3">{rev.title}</p>}
                    <p className="text-gray-600 text-sm mt-1 leading-relaxed">{rev.comment}</p>
                    {rev.isVerifiedPurchase && (
                      <span className="text-xs text-green-600 font-semibold mt-2 inline-block">✓ Verified Purchase</span>
                    )}
                  </div>
                ))
              )}
            </div>
          )}
        </div>
      </section>

      {/* Related Products */}
      {related.length > 0 && (
        <section className="py-12 bg-cream">
          <div className="container-custom">
            <h2 className="section-title mb-6">You May Also Like</h2>
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-4 gap-4 md:gap-5">
              {related.slice(0, 8).map((p) => <ProductCard key={p._id} product={p} />)}
            </div>
          </div>
        </section>
      )}
    </div>
  );
}

function ProductDetailSkeleton() {
  return (
    <div className="container-custom py-10">
      <div className="grid lg:grid-cols-2 gap-10">
        <div className="aspect-square skeleton rounded-3xl" />
        <div className="space-y-4">
          <div className="h-4 w-24 skeleton rounded" />
          <div className="h-10 skeleton rounded" />
          <div className="h-6 w-48 skeleton rounded" />
          <div className="h-16 skeleton rounded" />
          <div className="h-8 w-32 skeleton rounded" />
          <div className="h-12 skeleton rounded-xl" />
          <div className="h-12 skeleton rounded-xl" />
        </div>
      </div>
    </div>
  );
}
